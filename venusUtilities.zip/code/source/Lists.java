

// -----( IS Java Code Template v1.2
// -----( CREATED: 2011-05-26 10:26:22 PDT
// -----( ON-HOST: MCJHOM.AME.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.app.b2b.server.ns.*;
import com.wm.lang.ns.*;
import java.util.*;
import com.wm.app.b2b.server.dispatcher.*;
import com.wm.app.b2b.server.dispatcher.comms.*;
import java.io.FileWriter;
import com.wm.util.Name;
import com.wm.msg.*;
import com.wm.app.b2b.server.dispatcher.trigger.*;
import com.wm.app.b2b.server.*;
// --- <<IS-END-IMPORTS>> ---

public final class Lists

{
	// ---( internal utility methods )---

	final static Lists _instance = new Lists();

	static Lists _newInstance() { return new Lists(); }

	static Lists _cast(Object o) { return (Lists)o; }

	// ---( server methods )---




	public static final void add (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(add)>> ---
		// @sigtype java 3.5
		// [i] field:0:required key
		// [i] field:0:required store
		IDataCursor idc = pipeline.getCursor();
		String key = IDataUtil.getString(idc, "key");
		String store = IDataUtil.getString(idc, "store");
		
		TreeSet<String> i = notificationMap.get(store);
		if (i == null) {
			i = new TreeSet<String>();
			i.add(key);
			notificationMap.put(store, i);
		} else {
			i.add(key);
			notificationMap.put(key, i);
		}
		//System.out.println("Notification Map: Adding to HashMap for " + store + ": " + i);
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void get (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(get)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required store
		// [o] field:1:required list
		IDataCursor idc = pipeline.getCursor();
		String store = IDataUtil.getString(idc,"store");
		
		TreeSet<String> i = notificationMap.get(store);
		System.out.println("NotificationMap: Getting list for " + store + ": " + i);
		if (i == null) {
		i = new TreeSet<String>();
		} 
		Object[] o = i.toArray();
		String[] s = Arrays.copyOf(o, o.length, String[].class);
		IDataUtil.put(idc, "list", s);
		
		idc.destroy(); 
		// --- <<IS-END>> ---

                
	}



	public static final void init (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(init)>> ---
		// @sigtype java 3.5
		// [i] field:0:required store
		IDataCursor idc = pipeline.getCursor();
		String store = IDataUtil.getString(idc,"store");
		System.out.println("*************** Initializing NotificationMap");
		notificationMap.put(store, new TreeSet<String>());
		idc.destroy();
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	private static HashMap<String, TreeSet<String>> notificationMap = new HashMap<String,TreeSet<String>>();
	// --- <<IS-END-SHARED>> ---
}

