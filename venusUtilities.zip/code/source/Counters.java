

// -----( IS Java Code Template v1.2
// -----( CREATED: 2011-05-19 09:53:59 PDT
// -----( ON-HOST: MCJHOM.AME.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.app.b2b.server.ns.*;
import com.wm.lang.ns.*;
import java.util.*;
import com.wm.app.b2b.server.dispatcher.*;
import com.wm.app.b2b.server.dispatcher.comms.*;
import java.io.FileWriter;
import com.wm.util.Name;
import com.wm.msg.*;
import com.wm.app.b2b.server.dispatcher.trigger.*;
import com.wm.app.b2b.server.*;
// --- <<IS-END-IMPORTS>> ---

public final class Counters

{
	// ---( internal utility methods )---

	final static Counters _instance = new Counters();

	static Counters _newInstance() { return new Counters(); }

	static Counters _cast(Object o) { return (Counters)o; }

	// ---( server methods )---




	public static final void getNotificationCounter (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getNotificationCounter)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required key
		// [o] field:0:required count
		IDataCursor idc = pipeline.getCursor();
		String key = IDataUtil.getString(idc,"key");
		
		Integer i = notificationCounter.get(key);
		System.out.println("NotificationCounter: Getting counter for " + key + ": " + i);
		if (i == null) {
		idc.insertAfter("count", 0);
		} else {
		idc.insertAfter("count", i.toString());
		}
		
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getRetryCount (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getRetryCount)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required key
		// [o] field:0:required retryCount
		IDataCursor idc = pipeline.getCursor();
		String key = IDataUtil.getString(idc,"key");
		
		Integer i = retryCounter.get(key);
		System.out.println("RetryCounter: Getting counter for " + key + ": " + i);
		if (i == null) {
		idc.insertAfter("retryCount", 0);
		} else {
		idc.insertAfter("retryCount", i.toString());
		}
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void incrementNotificationCounter (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(incrementNotificationCounter)>> ---
		// @sigtype java 3.5
		// [i] field:0:required key
		IDataCursor idc = pipeline.getCursor();
		String key = IDataUtil.getString(idc, "key");
		Integer i = notificationCounter.get(key);
		if (i == null) {
			notificationCounter.put(key, 1); 
			i = 1;
		} else {
			i++;
			notificationCounter.put(key, i);
		}
		System.out.println("Notification Counter: Incrementing HashMap for " + key + ": " + i);
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void initializeNotificationCounter (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(initializeNotificationCounter)>> ---
		// @sigtype java 3.5
		// [i] field:0:required key
		IDataCursor idc = pipeline.getCursor();
		String key = IDataUtil.getString(idc,"key");
		System.out.println("*************** Initializing NotificationCounter to 0");
		notificationCounter.put(key, 0);
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void putRetryCount (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(putRetryCount)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required key
		// [i] field:0:required retryCount
		IDataCursor idc = pipeline.getCursor();
		String key = IDataUtil.getString(idc,"key");
		String rC = IDataUtil.getString(idc, "retryCount");
		Integer r = Integer.valueOf(rC);
		
		retryCounter.put(key, r);
		System.out.println("Putting counter for " + key + ": " + r);
		idc.destroy();
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	private static HashMap<String, Integer> retryCounter = new HashMap<String,Integer>();
	private static HashMap<String, Integer> notificationCounter = new HashMap<String,Integer>();
	// --- <<IS-END-SHARED>> ---
}

