package Settings;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2009-05-28 12:21:39 PDT
// -----( ON-HOST: MCJHOM.AME.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.text.*;
import java.util.*;
import com.wm.util.Config;
// --- <<IS-END-IMPORTS>> ---

public final class Extended

{
	// ---( internal utility methods )---

	final static Extended _instance = new Extended();

	static Extended _newInstance() { return new Extended(); }

	static Extended _cast(Object o) { return (Extended)o; }

	// ---( server methods )---




	public static final void getWattProperty (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getWattProperty)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required key
		// [o] field:0:required value
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		java.lang.String key = IDataUtil.getString( pipelineCursor, "key" );
		
		pipelineCursor.insertAfter("value", Config.getProperty(key));
		// --- <<IS-END>> ---

                
	}



	public static final void setWattProperty (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(setWattProperty)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required key
		// [i] field:0:required value
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		java.lang.String	key = IDataUtil.getString( pipelineCursor, "key" );
		java.lang.String	value = IDataUtil.getString( pipelineCursor, "value" );
		pipelineCursor.destroy();
		
		Config.setProperty(key, value);
		// --- <<IS-END>> ---

                
	}
}

