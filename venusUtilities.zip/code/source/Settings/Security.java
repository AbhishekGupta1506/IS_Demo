package Settings;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2009-05-28 12:21:45 PDT
// -----( ON-HOST: MCJHOM.AME.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.text.*;
// --- <<IS-END-IMPORTS>> ---

public final class Security

{
	// ---( internal utility methods )---

	final static Security _instance = new Security();

	static Security _newInstance() { return new Security(); }

	static Security _cast(Object o) { return (Security)o; }

	// ---( server methods )---




	public static final void sortCertificatesList (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(sortCertificatesList)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:1:required sortList
		// [i] record:1:required docList
		// [o] record:1:required sortedDocList
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String[] sortList = IDataUtil.getStringArray( pipelineCursor, "sortList" );
		
			int size = sortList.length;
		
			// docList
			IData[]	docList = IDataUtil.getIDataArray( pipelineCursor, "docList" );
		
			IData[]	sortedDocList = new IData[size];
		
			//for (int i = 0; i < size; i++)
				//sortedDocList[i] = IDataFactory.create();
			
			if ( docList != null && sortList != null)
			{
				for ( int i = 0; i < size; i++ )
				{
		
					for (int j = 0; j < size; j++)
					{
						IDataCursor tmpCursor1 = docList[j].getCursor();
						IData info = IDataUtil.getIData( tmpCursor1, "certificateInfo" );			
						IDataCursor tmpCursor2 = info.getCursor();
						String compStr = IDataUtil.getString( tmpCursor2, "subjectCN" );
						
						tmpCursor1.destroy();
						tmpCursor2.destroy();
		
						if (compStr.equals(sortList[i]))
						{
							System.out.println(sortList[i]);
							sortedDocList[i] = docList[j];
						}
					}
					
		
				}
			}
		
		
			IDataUtil.put(pipelineCursor, "sortedDocList", sortedDocList);
		
		pipelineCursor.destroy();
		
		// pipeline
		// --- <<IS-END>> ---

                
	}
}

