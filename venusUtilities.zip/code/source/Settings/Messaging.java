package Settings;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2009-05-28 12:21:42 PDT
// -----( ON-HOST: MCJHOM.AME.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.*;
import com.wm.app.b2b.server.*;
import java.net.InetAddress;
import com.wm.lang.ns.*;
import com.wm.app.b2b.server.dispatcher.*;
// --- <<IS-END-IMPORTS>> ---

public final class Messaging

{
	// ---( internal utility methods )---

	final static Messaging _instance = new Messaging();

	static Messaging _newInstance() { return new Messaging(); }

	static Messaging _cast(Object o) { return (Messaging)o; }

	// ---( server methods )---




	public static final void enableTrigger (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(enableTrigger)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required enable
		// [i] field:0:required node_nsName
		IDataCursor idc = pipeline.getCursor();  
		String nsName = IDataUtil.getString(idc,"node_nsName");
		NSName nsn = NSName.create(nsName);
		com.wm.app.b2b.server.ns.Namespace ns = com.wm.app.b2b.server.ns.Namespace.current();
		NSNode node = ns.getNode(nsn); 
		// this is a trigger
		NSTrigger nst = (NSTrigger) node;
		boolean enabled = IDataUtil.getBoolean(idc,"enable");
		IData triggerData = nst.getAsData();
		IDataCursor tdc = triggerData.getCursor();
		IData trigger = IDataUtil.getIData(tdc,"trigger");
		if (enabled) {
			System.err.println("Enabling trigger "+nsName);
			IDataCursor tc = trigger.getCursor();
			IDataUtil.put(tc,"deliverEnabled","true");
			IDataUtil.put(tc,"executeEnabled","true");
			tc.destroy();
		} else {
			System.err.println("Disabling trigger "+nsName);
			IDataCursor tc = trigger.getCursor();
			IDataUtil.put(tc,"deliverEnabled","false");
			IDataUtil.put(tc,"executeEnabled","false");
			tc.destroy();
		}
		IDataUtil.put(tdc,"trigger",trigger);
		tdc.destroy();
		idc.destroy();
		
		
		try {
		Service.doInvoke("wm.server.ns","putNode",triggerData);
		} catch (Exception e) {
			throw new ServiceException(e);
		}
		// --- <<IS-END>> ---

                
	}



	public static final void getServerInfo (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getServerInfo)>> ---
		// @sigtype java 3.5
		// [o] field:0:required port
		// [o] field:0:required host
		// [o] field:0:required ipaddr
		IDataCursor ic = pipeline.getCursor();
		String port = Integer.toString(ServerAPI.getCurrentPort());
		String host = ServerAPI.getServerName();
		String ipaddr = null;
		try {
		   ipaddr = InetAddress.getByName(host).getHostAddress();
		} catch ( java.net.UnknownHostException e ) {
		   ic.destroy();
		   return;
		}
		ic.insertAfter("port", port);
		ic.insertAfter("host", host);
		ic.insertAfter("ipaddr", ipaddr);
		ic.destroy();
		
		// --- <<IS-END>> ---

                
	}



	public static final void getTryCount (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getTryCount)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] field:0:required tryCount
		//Output Variables 
			String tryCount = "0"; 
		
		//this service prints the Retry count of the trigger if it
		//is present in the ProtocolInfoIf
		ProtocolInfoIf pif = InvokeState.getCurrentState().getProtocolInfoIf();
		if(pif!=null) 
		{
			 tryCount =
		(String)pif.getProtocolProperty(Dispatcher.DELIVERY_COUNT_KEY);
		//	System.out.println("The trigger delivery count="+retryCount);;
		}
		
			//define input variables 
			IDataCursor idcPipeline = pipeline.getCursor();
		
			//insert the tryCount into the pipeline
			idcPipeline.insertAfter("tryCount", tryCount);	
		
			//Always destroy cursors that you created
			idcPipeline.destroy();
		// --- <<IS-END>> ---

                
	}
}

