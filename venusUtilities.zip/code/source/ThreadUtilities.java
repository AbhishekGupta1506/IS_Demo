

// -----( IS Java Code Template v1.2
// -----( CREATED: 2012-08-17 20:42:21 PDT
// -----( ON-HOST: MCJHOM002.AME.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.util.Arrays;
// --- <<IS-END-IMPORTS>> ---

public final class ThreadUtilities

{
	// ---( internal utility methods )---

	final static ThreadUtilities _instance = new ThreadUtilities();

	static ThreadUtilities _newInstance() { return new ThreadUtilities(); }

	static ThreadUtilities _cast(Object o) { return (ThreadUtilities)o; }

	// ---( server methods )---




	public static final void exec (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(exec)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:1:required command
		// [i] field:1:optional env
		// [i] field:0:optional workingDirectory
		// [o] field:0:required result
		IDataCursor idc = pipeline.getCursor();
		String[] command = IDataUtil.getStringArray(idc, "command");
		String[] envp = IDataUtil.getStringArray(idc, "env");
		String workingDir = IDataUtil.getString(idc, "workingDirectory");
		File wDir = null;
		String result = "";
		try {
			if (workingDir != null) {
				wDir = new File(workingDir);
			}
			System.out.println("command to be executed: " + command[0] + " (" + Arrays.toString(command) + ") in " + workingDir);
			System.out.println("env: " + Arrays.toString(envp));
			
			Runtime r = Runtime.getRuntime();
			Process p = r.exec(command, envp, wDir);
			// put a BufferedReader on the command output
		
			BufferedReader bufferedreader = new BufferedReader(
					new InputStreamReader(p.getInputStream()));
			BufferedReader errorReader = new BufferedReader(
					new InputStreamReader(p.getErrorStream()));
		
			System.out.println("Get command output:");
			// read the command output
		
			String line;
			while ((line = bufferedreader.readLine()) != null) {
				line = "output> " + line;
				result = result + line + "\n";
			}
		
			// read command errors
			while ((line = errorReader.readLine()) != null) {
				line = "error> " + line;
				result = result + line + "\n";
			}
		
			System.out.println("Command complete: " + result);
			bufferedreader.close();
			errorReader.close();
			p.destroy();
		
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServiceException(e);
		}
		IDataUtil.put(idc, "result",result);
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void sleep (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(sleep)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required sleepTime
		IDataCursor ic = pipeline.getCursor();
		String time=null;
		 
		if ( ic.first("sleepTime") )
			time = (String)ic.getValue();
		
		try
		{
			Thread.sleep( Integer.parseInt(time) );
		}
		catch ( InterruptedException e ) 
		{
			//Print the exception out to standard output
			e.printStackTrace();
		}
		
		ic.destroy();
		
		// --- <<IS-END>> ---

                
	}
}

