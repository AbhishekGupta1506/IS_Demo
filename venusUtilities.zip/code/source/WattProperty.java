

// -----( IS Java Code Template v1.2
// -----( CREATED: 2009-05-28 12:21:52 PDT
// -----( ON-HOST: MCJHOM.AME.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.text.*;
import java.util.*;
import com.wm.util.Config;
// --- <<IS-END-IMPORTS>> ---

public final class WattProperty

{
	// ---( internal utility methods )---

	final static WattProperty _instance = new WattProperty();

	static WattProperty _newInstance() { return new WattProperty(); }

	static WattProperty _cast(Object o) { return (WattProperty)o; }

	// ---( server methods )---




	public static final void setWattProperty (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(setWattProperty)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required key
		// [i] field:0:required value
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		java.lang.String	key = IDataUtil.getString( pipelineCursor, "key" );
		java.lang.String	value = IDataUtil.getString( pipelineCursor, "value" );
		pipelineCursor.destroy();
		 
		Config.setProperty(key, value);
		// --- <<IS-END>> ---

                
	}
}

