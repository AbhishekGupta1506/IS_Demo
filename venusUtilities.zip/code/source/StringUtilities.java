

// -----( IS Java Code Template v1.2
// -----( CREATED: 2011-12-21 10:33:31 EST
// -----( ON-HOST: MCRESLOAN02.AME.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.text.*;
import java.util.*;
import com.wm.util.Config;
// --- <<IS-END-IMPORTS>> ---

public final class StringUtilities

{
	// ---( internal utility methods )---

	final static StringUtilities _instance = new StringUtilities();

	static StringUtilities _newInstance() { return new StringUtilities(); }

	static StringUtilities _cast(Object o) { return (StringUtilities)o; }

	// ---( server methods )---




	public static final void compareLists (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(compareLists)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:1:required list1
		// [i] field:1:required list2
		// [o] field:0:required result
		// [o] field:1:required elementsInList1NotInList2
		// [o] field:1:required elementsInList2NotInList1
		// [o] field:1:required elementsInCommon
		// pipeline
		
		IDataCursor pipelineCursor = pipeline.getCursor();
		
		String[] list1 = IDataUtil.getStringArray( pipelineCursor, "list1" );
		String[] list2 = IDataUtil.getStringArray( pipelineCursor, "list2" );
		
		Collection<String> c1 = new ArrayList<String>();
		Collection<String> c2 = new ArrayList<String>();
		
		if (list1 != null) {
			c1 = Arrays.asList(list1);
		}
		
		if (list2 != null) {
			c2 = Arrays.asList(list2);
		}
		
		Set<String> s1 = new TreeSet<String>();
		Set<String> s2 = new TreeSet<String>();
		s1.addAll(c1);
		s2.addAll(c2);
		
		
		// Create set containing all elements (assumes no duplicates)
		Set<String> common = new TreeSet<String>();
		common.addAll(c1);
		common.addAll(c2); 
		
		// Remove original lists to get difference
		s1.removeAll(c2);
		s2.removeAll(c1);
		
		// Remove the difference to get the common elements
		common.removeAll(s1);
		common.removeAll(s2);
		
		String result = "";
		
		if (s1.isEmpty() && s2.isEmpty()) {
		            result = "equal";
		} else {
		            result = "notEqual";
		}
		
		Object[] o = s1.toArray();
		String[] ss1 = Arrays.copyOf(o, o.length, String[].class);
		o = s2.toArray();
		String[] ss2 = Arrays.copyOf(o, o.length, String[].class);
		o = common.toArray();
		String[] c = Arrays.copyOf(o, o.length, String[].class);
		
		IDataUtil.put(pipelineCursor, "result", result);
		IDataUtil.put(pipelineCursor, "elementsInList1NotInList2", ss1);
		IDataUtil.put(pipelineCursor, "elementsInList2NotInList1", ss2);
		IDataUtil.put(pipelineCursor, "elementsInCommon", c);
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void contains (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(contains)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required string
		// [i] field:0:required substring
		// [o] field:0:required result
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		java.lang.String string1 = IDataUtil.getString(pipelineCursor, "string");
		java.lang.String string2 = IDataUtil.getString(pipelineCursor, "substring");
		java.lang.String result = "false";
		
		if (string1.contains(string2))
			result = "true";
		
		IDataUtil.put(pipelineCursor, "result", result);
		pipelineCursor.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void equal (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(equal)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required string1
		// [i] field:0:required string2
		// [o] field:0:required result
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		java.lang.String string1 = IDataUtil.getString(pipelineCursor, "string1");
		java.lang.String string2 = IDataUtil.getString(pipelineCursor, "string2");
		java.lang.String result = "false";
		
		if (string1.equals(string2))
			result = "true";
		
		IDataUtil.put(pipelineCursor, "result", result);
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void startsWith (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(startsWith)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required string
		// [i] field:0:required substring
		// [o] field:0:required result
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		java.lang.String string1 = IDataUtil.getString(pipelineCursor, "string");
		java.lang.String string2 = IDataUtil.getString(pipelineCursor, "substring");
		java.lang.String result = "false";
		
		if (string1.startsWith(string2))
			result = "true";
		
		IDataUtil.put(pipelineCursor, "result", result);
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void stringListCompareAndSort (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(stringListCompareAndSort)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:1:required unsortedList
		// [o] field:1:required sortedList
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String[]	unsortedList = IDataUtil.getStringArray( pipelineCursor, "unsortedList" );
			String[]    sortedList = null;
		
		if ( unsortedList != null)
		{
			int size = unsortedList.length;
		
			sortedList = new String[size];
		
			Collator myCollator = Collator.getInstance();
		 	// Create an array of CollationKeys for the Strings to be sorted.
		 	CollationKey[] keys = new CollationKey[size];
		
			for (int i = 0; i < size; i++)
				keys[i] = myCollator.getCollationKey(unsortedList[i]);
		 
		
				try
				{
		
					for (int i = 0; i < size; i++) {
						for (int j = i + 1; j < size; j++) 
						{
			    			if (keys[i].compareTo( keys[j] ) > 0 ) 
							{
								CollationKey tempKey = keys[i] ;
								keys[i] = keys[j];
								keys[j] = tempKey;
			    			}
						}
		    		}
		
					sortedList = new String[size];
		
					for (int i = 0; i < size; i++)
					{
						sortedList[i] = keys[i].getSourceString();
					}
		
					//Now lets spitout the sort order.
					IDataUtil.put( pipelineCursor, "sortedList", sortedList );
		
		
			}
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
		
		//End cursor.
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}
}

