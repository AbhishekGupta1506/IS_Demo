

// -----( IS Java Code Template v1.2
// -----( CREATED: 2013-02-27 07:44:28 PST
// -----( ON-HOST: MCJHOM002.AME.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.softwareag.util.IDataMap;
// --- <<IS-END-IMPORTS>> ---

public final class stringContains

{
	// ---( internal utility methods )---

	final static stringContains _instance = new stringContains();

	static stringContains _newInstance() { return new stringContains(); }

	static stringContains _cast(Object o) { return (stringContains)o; }

	// ---( server methods )---




	public static final void genericStringContains (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(genericStringContains)>> ---
		// @sigtype java 3.5
		// [i] field:0:required matchOn
		// [i] field:0:required inputString
		// [i] field:1:required inputStringArray
		// [i] record:0:required inputDocument
		// [i] record:1:required inputDocumentArray
		// [i] record:0:required logEntries
		// [o] field:0:required containedFlag
		//System.out.println(pipeline);
		//System.out.println(pipeline.getClass().getName());
		//IDataFormatter formatter = new IDataFormatter();
		//formatter.print(System.out, pipeline);
		 
		IDataMap pipe = new IDataMap(pipeline);
		String matchOn = pipe.getAsString("matchOn");
		
		
		//Object o = pipe.get("inputDocument");
		//if (o == null) {
			//System.out.println("NULL!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
		    //pipe.put("type", o.getClass().getName());
		//}
		
		//Input from pipeline is a string if str is not null.
		String str = pipe.getAsString("inputString");
		if (str != null) {
			//pipe.put("type", str.getClass().getName());
			if (str.indexOf(matchOn) > -1) {
				pipe.put("containedFlag", "true");
			}
		}
				
		//Input from pipeline is a string array if stackTrace is not null	
		String[] stackTrace = pipe.getAsStringArray("inputStringArray");
		if (stackTrace != null) {
			for (String element : stackTrace) {
				if (element.indexOf(matchOn) > -1) {
					pipe.put("containedFlag", "true");
					break;
				}
			}
		} 
				 
		//Input from pipeline is an IData/document if doc is not null.
		//Preferred method is to drill down to the element of the structure you wish to 
		//  search within the flow service, but some services return a pipeline with
		//  an undefined structure such as index/key eg getPartialLog.
		Object doc = pipe.getAsIData("inputDocument");
		if (doc != null) {
			System.out.println("doc as input");
			String docToStr = doc.toString();
			if (docToStr.indexOf(matchOn) > -1) {
				pipe.put("containedFlag", "true");
			}
		}
			
		//Input from pipeline is a document/IData array if objectArrayFromDoc is not null.
		//Preferred method is to drill down to the element of the structure you wish to 
		//  search within the flow service, but some services return a pipeline with
		//  an undefined structure such as index/key eg getPartialLog.
		Object[] objectArrayFromDoc = pipe.getAsIDataArray("inputDocumentArray");
		if (objectArrayFromDoc != null) {
			for (Object objParsed :  objectArrayFromDoc) {
				String convertedStr = objParsed.toString();
				if (convertedStr.indexOf(matchOn) > -1) {
					pipe.put("containedFlag", "true");
					break;
				}
			}
		}
			
		//Special case for partial logs.		
		String str2 = pipe.getAsString("logEntries");
		if (str2 != null) {
			if (str2.indexOf(matchOn) > -1) {
				pipe.put("containedFlag", "true");
			}
		}
					
		// --- <<IS-END>> ---

                
	}
}

