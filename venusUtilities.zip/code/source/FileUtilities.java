

// -----( IS Java Code Template v1.2
// -----( CREATED: 2012-08-23 15:58:43 PDT
// -----( ON-HOST: MCJHOM002.AME.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.*;
import java.util.zip.ZipFile;
import java.util.zip.ZipEntry;
import java.util.Enumeration;
import java.util.Scanner;
// --- <<IS-END-IMPORTS>> ---

public final class FileUtilities

{
	// ---( internal utility methods )---

	final static FileUtilities _instance = new FileUtilities();

	static FileUtilities _newInstance() { return new FileUtilities(); }

	static FileUtilities _cast(Object o) { return (FileUtilities)o; }

	// ---( server methods )---




	public static final void appendToFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(appendToFile)>> ---
		// @sigtype java 3.5
		// [i] field:0:required filename
		// [i] field:0:required line
		// [i] object:0:optional checkExistence
		IDataCursor idc = pipeline.getCursor();  
		String filename = IDataUtil.getString(idc,"filename");
		String line = IDataUtil.getString(idc,"line");
		boolean checkExistence = IDataUtil.getBoolean(idc, "checkExistence");
		String result = "";
		boolean found = false;
		
		if (checkExistence) {
			Scanner in = null;
			try {
				in = new Scanner(new FileReader(new File(filename)));
				while (in.hasNextLine() && !found) {
					found = in.nextLine().indexOf(line) > 0;
				}
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
				try { in.close(); } catch (Exception e) { /* ignore */ }
			}
		}
		
		if (!(checkExistence && found)) {
			try {
				FileWriter fw = new FileWriter(filename, true);
				BufferedWriter bw = new BufferedWriter(fw);
				bw.write(line + "\n");
				bw.close();
			} catch (Exception e) {
				result = e.getMessage();
			}
		} else {
			result = "String (" + line + ") already exists in file: " + filename;
		}
		IDataUtil.put(idc, "result", result);
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void bytesToFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(bytesToFile)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required filename
		// [i] object:0:required bytes
		IDataCursor idc = pipeline.getCursor();  
		String nsName = IDataUtil.getString(idc,"filename");
		byte[] byteArray = (byte[])IDataUtil.get(idc,"bytes");
		try {
		 FileOutputStream out = new FileOutputStream(nsName);
		out.write(byteArray);
		out.close();
		} catch (Exception e) {}
		idc.destroy(); 
		// --- <<IS-END>> ---

                
	}



	public static final void compareZipFileContent (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(compareZipFileContent)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required file
		// [i] field:0:required zipfile
		// [o] field:0:required result
		IDataCursor idc = pipeline.getCursor();  
		String filename = IDataUtil.getString(idc,"file");
		String zfname = IDataUtil.getString(idc,"zipfile");
		boolean equal = true;
		try {
		ZipFile zf = new ZipFile(zfname);
		 
		FileInputStream fstream = new FileInputStream(filename);
		InputStream zstream = zf.getInputStream(zf.getEntry(filename));
		
		while (equal && (fstream.available() > 0) && (zstream.available() > 0)) {
			equal = equal && (fstream.read() == zstream.read());
		}
		
		} catch (java.io.IOException ex) { 
			ex.printStackTrace(); 
		}
		idc.last();
		String result = equal ? "equal" : "notEqual";
		IDataUtil.put(idc,"result",result);
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void compareZipFiles (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(compareZipFiles)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required file1
		// [i] field:0:required file2
		// [o] field:0:required result
		IDataCursor idc = pipeline.getCursor();  
		String filename1 = IDataUtil.getString(idc,"file1");
		String filename2 = IDataUtil.getString(idc,"file2");
		boolean equal = true;
		try {
		ZipFile f1 = new ZipFile(filename1);
		ZipFile f2 = new ZipFile(filename2);
		int i = 0; 
		 
		// This method assumes that you've already compared the 
		for (Enumeration e = f1.entries() ; e.hasMoreElements() ;) {
			ZipEntry entry1 = (ZipEntry)e.nextElement(); 
		     	ZipEntry entry2 = f2.getEntry(entry1.getName());
		
			equal = equal && (entry1.getName().equals(entry2.getName()));
			equal = equal && (entry1.getTime() == entry2.getTime());
			equal = equal && (entry1.getSize() == entry2.getSize());
			i++;
			if (!equal)
				break;
		}
		
		} catch (java.io.IOException ex) { 
			ex.printStackTrace(); 
		}
		idc.last();
		String result = equal ? "equal" : "notEqual";
		IDataUtil.put(idc,"result",result);
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void copyFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(copyFile)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required filename
		// [i] field:0:required targetfile
		// [o] field:0:required result
		IDataCursor idc = pipeline.getCursor();  
		String nsName = IDataUtil.getString(idc,"filename");
		String targetFile = IDataUtil.getString(idc,"targetfile");
		String result = "Copy " + nsName + " to " + targetFile + ", result: ";
		 
		System.out.println(result); 
		try{ 
		      File f1 = new File(nsName);
		      File f2 = new File(targetFile);
		      InputStream in = new FileInputStream(f1);
		      
		      //For Append the file.
		//      OutputStream out = new FileOutputStream(f2,true);
		
		      //For Overwrite the file.
		      OutputStream out = new FileOutputStream(f2);
		
		      byte[] buf = new byte[1024];
		      int len;
		      while ((len = in.read(buf)) > 0){
		        out.write(buf, 0, len);
		      }
		      in.close();
		      out.close();
		      result += "File copied.";
		    }
		    catch(FileNotFoundException ex){
		      result = ex.getMessage() + " in the specified directory.";
		    }
		    catch(IOException e){
		      result = e.getMessage();      
		    }
		System.out.println(result);
		
		idc.last();
		IDataUtil.put(idc,"result",result);
		idc.destroy();
		
		// --- <<IS-END>> ---

                
	}



	public static final void deleteFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(deleteFile)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required filename
		// [o] field:0:required result
		IDataCursor idc = pipeline.getCursor();  
		String nsName = IDataUtil.getString(idc,"filename");
		File f = new File(nsName);
		Boolean b = false;
		if (f.exists()) {
			b = f.delete();
		}
		idc.last();
		IDataUtil.put(idc,"result",Boolean.toString(b));
		idc.destroy();
		
		// --- <<IS-END>> ---

                
	}



	public static final void exists (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(exists)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required filename
		// [o] field:0:required exists
		IDataCursor idc = pipeline.getCursor();  
		String nsName = IDataUtil.getString(idc,"filename");
		File f = new File(nsName);
		Boolean b = f.exists();
		idc.last();
		IDataUtil.put(idc,"exists",Boolean.toString(b));
		idc.destroy();
		
		// --- <<IS-END>> ---

                
	}



	public static final void getZipFileContentAsString (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getZipFileContentAsString)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required file
		// [i] field:0:required zipfile
		// [o] field:0:required result
		IDataCursor idc = pipeline.getCursor();  
		String filename = IDataUtil.getString(idc,"file");
		String zfname = IDataUtil.getString(idc,"zipfile");
		byte buffer[] = null; 
		try {
		ZipFile zf = new ZipFile(zfname);
		
		ZipEntry ze = zf.getEntry(filename);
		InputStream zstream = zf.getInputStream(ze);
		buffer = new byte[(int)ze.getSize()];
		zstream.read(buffer, 0, buffer.length);
		zstream.close();
		zf.close();
		
		} catch (java.io.IOException ex) { 
			ex.printStackTrace(); 
		}
		idc.last();
		IDataUtil.put(idc,"result", new String(buffer));
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void lastModified (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(lastModified)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required filename
		// [o] field:0:required lastModified
		IDataCursor idc = pipeline.getCursor();  
		String nsName = IDataUtil.getString(idc,"filename");
		File f = new File(nsName);
		long time = 0;
		if (f.exists()) {
			time = f.lastModified();
		}
		idc.last();
		System.out.println(time);
		IDataUtil.put(idc,"lastModified",Long.toString(time));
		idc.destroy();
		
		// --- <<IS-END>> ---

                
	}



	public static final void listFiles (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(listFiles)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required directory
		// [o] field:1:required files
		IDataCursor idc = pipeline.getCursor();  
		String nsName = IDataUtil.getString(idc,"directory");
		String[] stringArray;
		
		File f = new File(nsName);
		stringArray = f.list();
		
		idc.last();
		IDataUtil.put(idc,"files",stringArray);
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void replaceToken (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(replaceToken)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required filename
		// [i] field:0:required token
		// [i] field:0:required replacementString
		// [i] field:0:required regex
		// [o] field:0:required result
		IDataCursor idc = pipeline.getCursor();  
		String nsName = IDataUtil.getString(idc,"filename");
		String token = IDataUtil.getString(idc,"token");
		String replacementString = IDataUtil.getString(idc,"replacementString");
		String result = "Replacing " + token + " in " + nsName + " with " + replacementString + ", result: ";
		String regexS = IDataUtil.getString(idc, "regex");
		if (regexS == null) {
			regexS = "no";
		} 
		boolean regex = regexS.equalsIgnoreCase("yes") || regexS.equalsIgnoreCase("true");
		
		System.out.println(result); 
		
		try {
		    File file = new File(nsName);
		    BufferedReader reader = new BufferedReader(new FileReader(file));
		    String line = "", oldtext = "";
		    while((line = reader.readLine()) != null) {
		        oldtext += line + "\r\n";
		    }
		System.out.println("old: " + oldtext);
		    reader.close();
		    // replace a word in a file
			String newtext;
			if (regex) {
		     newtext = oldtext.replaceAll(token, replacementString);
			} else {
		     newtext = oldtext.replace(token, replacementString);
			}
		System.out.println("new: " + newtext);            
		    FileWriter writer = new FileWriter(nsName);
		    writer.write(newtext);writer.close();
		    result += "Replace complete.";
		} catch (IOException ioe) {
		    result = ioe.getMessage();    
		}
		
		System.out.println(result);
		
		idc.last();
		IDataUtil.put(idc,"result",result);
		idc.destroy();
		
		// --- <<IS-END>> ---

                
	}



	public static final void zipEntries (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(zipEntries)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required filename
		// [o] field:1:required entries
		IDataCursor idc = pipeline.getCursor();  
		String nsName = IDataUtil.getString(idc,"filename");
		String[] stringArray;
		try {
		ZipFile f = new ZipFile(nsName);
		stringArray = new String[f.size()];
		int i = 0;
		for (Enumeration e = f.entries() ; e.hasMoreElements() ;) {
			ZipEntry entry = (ZipEntry)e.nextElement();     
			stringArray[i] = entry.getName();
			i++;
		}
		
		} catch (java.io.IOException ex) { 
			ex.printStackTrace(); 
			stringArray = new String[1];
			stringArray[0] = ex.getMessage();
		}
		idc.last();
		IDataUtil.put(idc,"entries",stringArray);
		idc.destroy();
		// --- <<IS-END>> ---

                
	}
}

