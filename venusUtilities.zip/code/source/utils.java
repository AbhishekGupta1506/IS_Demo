

// -----( IS Java Code Template v1.2
// -----( CREATED: 2010-09-09 17:05:09 EDT
// -----( ON-HOST: usashbvt01.AME.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.ListIterator;
import com.wm.lang.jaxrpc.JAXHandlerRegistry;
import com.wm.lang.ns.NSName;
import com.wm.lang.ns.NSWSDescriptor;
import com.wm.lang.websvc.WSBinder;
import com.wm.lang.websvc.WSHandler;
import com.wm.app.b2b.server.ns.Namespace;
// --- <<IS-END-IMPORTS>> ---

public final class utils

{
	// ---( internal utility methods )---

	final static utils _instance = new utils();

	static utils _newInstance() { return new utils(); }

	static utils _cast(Object o) { return (utils)o; }

	// ---( server methods )---




	public static final void registerAliasWithWSD (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(registerAliasWithWSD)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required wsdName
		// [i] field:0:required aliasName
		  // --- <<IS-START(registerAliasWithWSD)>> ---
		  // @subtype unknown
		  // @sigtype java 3.5
		  // [i] field:0:required wsdName
		  // [i] field:0:required aliasName
		
		  // pipeline
		    IDataCursor pipelineCursor = pipeline.getCursor();
		    String wsdName = IDataUtil.getString( pipelineCursor, "wsdName" );
		    String aliasName = IDataUtil.getString( pipelineCursor, "aliasName" );
		    pipelineCursor.destroy();
		    NSWSDescriptor wsd = Namespace.getWebServiceDescriptor(NSName.create(wsdName));
		    ListIterator<WSBinder> binders = wsd.getBinderList();
		    while(binders.hasNext()){
		     WSBinder binder = binders.next();
		     binder.setPortAlias(aliasName);
		     System.out.println(aliasName + " attached with the Binder");
		}
		// --- <<IS-END>> ---

                
	}
}

