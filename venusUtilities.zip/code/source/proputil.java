

// -----( IS Java Code Template v1.2
// -----( CREATED: 2012-10-19 10:30:30 EDT
// -----( ON-HOST: MCPFINK02.eur.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.ArrayList;
import java.util.Set;
import com.softwareag.util.IDataMap;
import com.wm.util.text.Strings;
// --- <<IS-END-IMPORTS>> ---

public final class proputil

{
	// ---( internal utility methods )---

	final static proputil _instance = new proputil();

	static proputil _newInstance() { return new proputil(); }

	static proputil _cast(Object o) { return (proputil)o; }

	// ---( server methods )---




	public static final void getProperty (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getProperty)>> ---
		// @sigtype java 3.5
		// [i] field:0:required propertyName
		// [o] field:0:required propertyValue
		IDataMap map = new IDataMap(pipeline);
		String propName = map.getAsString("propertyName");
		if(Strings.isEmpty(propName)) {
			throw new ServiceException("propertyName is a required field. Please supply a value.");
		}
		map.put("propertyValue", System.getProperty(propName));
			
		// --- <<IS-END>> ---

                
	}



	public static final void removeProperties (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(removeProperties)>> ---
		// @sigtype java 3.5
		// [i] field:0:required propertyNamePrefix
		// [o] field:0:required deletedCount
		IDataMap map = new IDataMap(pipeline);
		String propNamePrefix = map.getAsString("propertyNamePrefix");
		if(Strings.isEmpty(propNamePrefix)) {
			throw new ServiceException("propertyNamePrefix is a required field. Please supply a value.");
		}
		Set<Object> keys = System.getProperties().keySet();
		ArrayList<String> propsToDelete = new ArrayList<String>();
		for(Object key: keys) {
			String propName = (String)key;
			if(propName.startsWith(propNamePrefix)) {
				propsToDelete.add(propName);
			} 
		}
		for(String propName: propsToDelete) {
			System.getProperties().remove(propName);
		}
		map.put("deletedCount", String.valueOf(propsToDelete.size()));
			
		// --- <<IS-END>> ---

                
	}



	public static final void removeProperty (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(removeProperty)>> ---
		// @sigtype java 3.5
		// [i] field:0:required propertyName
		IDataMap map = new IDataMap(pipeline);
		String propName = map.getAsString("propertyName");
		if(Strings.isEmpty(propName)) {
			throw new ServiceException("propertyName is a required field. Please supply a value.");
		}
		System.getProperties().remove(propName);
			
		// --- <<IS-END>> ---

                
	}



	public static final void setProperty (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(setProperty)>> ---
		// @sigtype java 3.5
		// [i] field:0:required propertyName
		// [i] field:0:required propertyValue
		IDataMap map = new IDataMap(pipeline);
		String propName = map.getAsString("propertyName");
		String propValue = map.getAsString("propertyValue");
		if(Strings.isEmpty(propName)) {
			throw new ServiceException("propertyName is a required field. Please supply a value.");
		}
		if(Strings.isEmpty(propValue)) {
			throw new ServiceException("propertyValue is a required field. Please supply a value.");
		}
		System.setProperty(propName, propValue);
		// --- <<IS-END>> ---

                
	}



	public static final void waitUntilPropertyRemoved (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(waitUntilPropertyRemoved)>> ---
		// @sigtype java 3.5
		// [i] field:0:required propertyName
		// [i] field:0:required totalWaittime
		IDataMap pipe = new IDataMap(pipeline);
		String propName = pipe.getAsString("propertyName");
		int totalWaittime = pipe.getAsInteger("totalWaittime", new Integer(30000)).intValue();
		long start = System.currentTimeMillis();
		while(true) {
			if(System.getProperty(propName) != null) {
				try
				{
					Thread.sleep(100);
				} catch(InterruptedException ie) {
					throw new ServiceException(ie);
				}
				if(System.currentTimeMillis()-start > totalWaittime) {
					break;
				}
				continue;
			} else {
				break;
			}
		}
			
		// --- <<IS-END>> ---

                
	}
}

