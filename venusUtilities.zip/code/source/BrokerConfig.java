

// -----( IS Java Code Template v1.2
// -----( CREATED: 2012-08-07 10:26:23 PDT
// -----( ON-HOST: MCJHOM002.AME.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.*;
import com.wm.lang.ns.*;
import com.wm.app.b2b.server.*;
import java.net.InetAddress;
import COM.activesw.api.client.*;
import com.wm.app.b2b.server.dispatcher.*;
import java.lang.*;
// --- <<IS-END-IMPORTS>> ---

public final class BrokerConfig

{
	// ---( internal utility methods )---

	final static BrokerConfig _instance = new BrokerConfig();

	static BrokerConfig _newInstance() { return new BrokerConfig(); }

	static BrokerConfig _cast(Object o) { return (BrokerConfig)o; }

	// ---( server methods )---




	public static final void broker_start (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(broker_start)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required broker_host
		// [i] field:0:required server_port
		// [i] field:0:required monitor_port
		// [o] field:0:required status
		IDataCursor ic = pipeline.getCursor();
		String brokerHostString = null;
		String statusString = null;
		int status = -999;
		int brokerServerPort = 6849;
		int brokerMonitorPort = 6850;
		
		if ( ic.first("broker_host") )
			brokerHostString = (String)ic.getValue();
		if ( ic.first("server_port") )
			brokerServerPort = Integer.parseInt((String)ic.getValue());
		if ( ic.first("monitor_port") )
			brokerMonitorPort = Integer.parseInt((String)ic.getValue()); 
		    
		int run_state = BrokerServerClient.SERVER_STATUS_STOPPED;
		String host = brokerHostString;
		int monitorPort=brokerMonitorPort;
		int brokerPort=brokerServerPort;
		
		        try {
		            run_state = BrokerServerClient.getServerProcessRunStatus(host, monitorPort, brokerPort);
		        }
		        catch (BrokerException ex) {
		        }
		
		        if (run_state == BrokerServerClient.SERVER_STATUS_RUNNING) {
		            System.out.println("Server already running on " + brokerHostString + ":" + brokerServerPort + ", monitor: " + brokerMonitorPort);
		        }  {
		            try {
		                BrokerServerClient.startServerProcess(host, monitorPort, brokerPort);
		                int i;
		                for (i = 0; i < 60; i++) {
		                    run_state = BrokerServerClient.getServerProcessRunStatus(host, monitorPort, brokerPort);
		                    //if (run_state == BrokerServerClient.SERVER_STATUS_RUNNING)
		                    //    break;
		                    if (i == 0)
		                        System.out.println("Starting the server " + brokerHostString + ":" + brokerServerPort + ", monitor: " + brokerMonitorPort);
		                    else
		                        System.out.print(".");
		                    System.out.flush();
		                    Thread.sleep(1000);
		                }
		                if (i != 0)
		                    System.out.println();
		
				run_state = BrokerServerClient.getServerProcessRunStatus(brokerHostString, brokerMonitorPort, brokerServerPort);
				if (run_state != BrokerServerClient.SERVER_STATUS_RUNNING) {
					
					System.out.println("Unable to start server " + brokerHostString + ":" + "brokerServerPort");
				} else {
					System.out.println("Started");
				}
		            }
		           catch (Exception ex) {
		                ex.printStackTrace();
		            }
		        }
		
		    
		BrokerConfig.broker_status(pipeline);
		ic.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void broker_status (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(broker_status)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required broker_host
		// [i] field:0:required server_port
		// [i] field:0:required monitor_port
		// [o] field:0:required status
		IDataCursor ic = pipeline.getCursor();
		String brokerHostString = "localhost";
		String statusString = "Unknown";
		int brokerServerPort = 6849;
			int brokerMonitorPort = 6850;
		 
		if ( ic.first("broker_host") )
			brokerHostString = (String)ic.getValue();
		if ( ic.first("server_port") )
			brokerServerPort = Integer.parseInt((String)ic.getValue());
		if ( ic.first("monitor_port") )
			brokerMonitorPort = Integer.parseInt((String)ic.getValue());
		//ic.delete();    
		 
		String brokerMonitorHost = brokerHostString;
		
		int status = -999;
		
		try {
			status = BrokerServerClient.getServerProcessRunStatus(brokerMonitorHost, brokerMonitorPort, brokerServerPort);
			System.out.println("status: " + status);
		
		} catch (BrokerException be) {
			System.out.println(be.toString());
		}
		
		if (status == BrokerServerClient.SERVER_STATUS_ERROR) {
			statusString = "ERROR";
		} else if (status == BrokerServerClient.SERVER_STATUS_RUNNING) {
			statusString = "RUNNING";
		} else if (status == BrokerServerClient.SERVER_STATUS_STARTING) {
			statusString = "STARTING";
		} else if (status == BrokerServerClient.SERVER_STATUS_STOPPED) {
			statusString = "STOPPED";
		} else if (status == BrokerServerClient.SERVER_STATUS_STOPPING) {
			statusString = "STOPPING";
		}
			
		
		ic.insertAfter("status", statusString);
		ic.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void broker_stop (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(broker_stop)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required broker_host
		// [i] field:0:required server_port
		// [i] field:0:required monitor_port
		// [o] field:0:required status
		IDataCursor ic = pipeline.getCursor();
		String brokerHostString = null;
		String statusString = null;
		int status = -999;
		int brokerServerPort = 6849;
			int brokerMonitorPort = 6850;
		
		if ( ic.first("broker_host") )
			brokerHostString = (String)ic.getValue();
		if ( ic.first("server_port") )
			brokerServerPort = Integer.parseInt((String)ic.getValue());
		if ( ic.first("monitor_port") )
			brokerMonitorPort = Integer.parseInt((String)ic.getValue());
		//ic.delete();    
		
		    	String broker = brokerHostString + ":" + brokerServerPort;
			String host=brokerHostString;
			int monitorPort = brokerMonitorPort;
			int serverPort = brokerServerPort;
		System.out.println("Stopping the server " + brokerHostString + ":" + brokerServerPort + ", monitor: " + brokerMonitorPort);
		 int run_state = BrokerServerClient.SERVER_STATUS_RUNNING;
		
		        try {
		            run_state = BrokerServerClient.getServerProcessRunStatus(host, monitorPort, serverPort);
		        }
		        catch (BrokerException ex) {
		            System.err.println(ex.getMessage());
				return;
		        }
		
		        if (run_state == BrokerServerClient.SERVER_STATUS_STOPPED) {
		            System.out.println("Server already stopped on " + brokerHostString + ":" + brokerServerPort + ", monitor: " + brokerMonitorPort);
		        }  else {
				for (int j = 0; j < 3; j++ ) {
		            try {
		                BrokerServerClient client = new BrokerServerClient(host+":"+serverPort, new BrokerConnectionDescriptor());
		                client.stopProcess();
		                int i;
		                for (i = 0; i < 60; i++) {
		                    run_state = BrokerServerClient.getServerProcessRunStatus(host, monitorPort, serverPort);
		                    //if (run_state == BrokerServerClient.SERVER_STATUS_STOPPED)
		                    //    break;
		                    if (i == 0)
		                        System.out.print("Broker stopping");
		                    else
		                        System.out.print(".");
		                    System.out.flush();
		                    Thread.sleep(1000);
		                }
		
				run_state = BrokerServerClient.getServerProcessRunStatus(brokerHostString, brokerMonitorPort, brokerServerPort);
				if (run_state != BrokerServerClient.SERVER_STATUS_STOPPED) {
					System.out.println("Unable to stop server " + brokerHostString + ":" + brokerServerPort);
				}else {
					System.out.println("Stopped");
				}
		            }
		
		            catch (Exception ex) {
				if (ex.getMessage().contains("Comm Failure")) {
					
				} else {
		                ex.printStackTrace();
				}
		            }
		          }
		        }
		
		
		BrokerConfig.broker_status(pipeline);
		ic.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void configureBasicAuth (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(configureBasicAuth)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required datadir
		IDataCursor idc = pipeline.getCursor();  
		String nsName = "packages/venusUtilities/pub/BrokerConfig/basicauth.cfg";
		String dataDir = IDataUtil.getString(idc, "datadir");
		String targetFile = dataDir + "/basicauth.cfg";
		String cfgFile = dataDir + "/awbroker.cfg";
		String result = "Copy " + nsName + " to " + targetFile + ", result: ";
		Boolean b = false;
		
		try {
		FileOutputStream appendedFile = new FileOutputStream(cfgFile, true);
		String cfgString = "basic-auth-cfg-file=" + targetFile + "\n";
		appendedFile.write(cfgString.getBytes());
		appendedFile.flush();
		appendedFile.close();
		
		System.out.println(result);
		
		File f1 = new File(nsName);
		      File f2 = new File(targetFile);
		      InputStream in = new FileInputStream(f1);
		
		      //For Overwrite the file.
		      OutputStream out = new FileOutputStream(f2);
		
		      byte[] buf = new byte[1024];
		      int len;
		      while ((len = in.read(buf)) > 0){
		        out.write(buf, 0, len);
		      }
		      in.close();
		      out.close();
		} catch (Exception e){
		      result = e.getMessage();      
		    } 
		
		
		
		// --- <<IS-END>> ---

                
	}



	public static final void createBroker (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(createBroker)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required broker_host
		// [i] field:0:required server_port
		// [i] field:0:required broker_name
		IDataCursor ic = pipeline.getCursor();
		String broker_host = null;
		String statusString = null;
		int status = -999;
		String broker = null;
		int brokerServerPort=6849; 
		 
		if ( ic.first("broker_host") ) {
			broker_host = (String)ic.getValue();
			if (broker_host == null) 
				broker_host = "localhost";
		}
		if ( ic.first("server_port") ) {
			String tmp = (String)ic.getValue();
			if (tmp == null) 
				brokerServerPort = 6849;
			else  brokerServerPort = Integer.parseInt(tmp);
		}
		if ( ic.first("broker_name") )
			broker = (String)ic.getValue();
		ic.delete();
		
		BrokerServerClient client = null;
		
		String foo = null;
		try {
			client = new BrokerServerClient(broker_host + ":" + brokerServerPort, null); 
			client.createBroker(broker,"venus Broker",false);
		} catch (BrokerException be) {
			System.out.println(be.toString());
		}
		
		ic.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void createTerritory (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(createTerritory)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required broker_host
		// [i] field:0:required server_port
		// [i] field:1:required broker_names
		// [i] field:0:required territory_name
		// [o] field:0:required status
		
		IDataCursor ic = pipeline.getCursor();
		String broker_host = null;
		String statusString = null;
		String brokerNames[] = null;
		BrokerInfo brokers[] = null;
		String territoryName=null;
		int brokerServerPort = 6849;
		
		if ( ic.first("broker_host") )
			broker_host = (String)ic.getValue();
		if ( ic.first("server_port") )
			brokerServerPort = Integer.parseInt((String)ic.getValue());
		if ( ic.first("broker_names") )
			brokerNames = (String[])ic.getValue();
		if ( ic.first("territory_name") )
			territoryName = (String)ic.getValue();
		
		ic.delete();
		
		BrokerAdminClient aclient1 = null;
		
		try{
		       aclient1 = BrokerAdminClient.newOrReconnectAdmin(broker_host + ":" + brokerServerPort, brokerNames[0], 
				"BrokerUtils Admin", "admin", "venus", null);
			aclient1.createTerritory(territoryName);
			aclient1.disconnectClientById("BrokerUtils Admin");
			for (int i = 1; i < brokerNames.length; i++) {
				aclient1 = BrokerAdminClient.newOrReconnectAdmin(broker_host + ":" + brokerServerPort, brokerNames[i], 
				"BrokerUtils Admin", "admin", "venus", null);
				if (aclient1.joinTerritory(broker_host, brokerNames[0]) != null) {
					statusString = statusString + " -- " + brokerNames[i] + ": Could not join territory --";
				}
				aclient1.disconnectClientById("BrokerUtils Admin");
			}
		} catch (BrokerException be) {
			statusString = be.toString();
		}	
		
		if (statusString == null) {
		try {
		aclient1 = BrokerAdminClient.newOrReconnectAdmin(broker_host + ":" + brokerServerPort, brokerNames[0], 
				"BrokerUtils Admin", "admin", "venus", null);
		              brokers = aclient1.getBrokersInTerritory();
					statusString = "";
		        		for(int j=0; j < brokers.length; ++j) {
		          	  		statusString = statusString + "--" + brokers[j].broker_name + "--";
					}
		               aclient1.disconnectClientById("BrokerUtils Admin");
		} catch (BrokerException e) {}
		}
		ic.insertAfter("status", statusString);
		ic.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void deleteBroker (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(deleteBroker)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required broker_host
		// [i] field:0:required server_port
		// [i] field:0:required broker_name
		IDataCursor ic = pipeline.getCursor();
		String broker_host = null;
		String statusString = null;
		int status = -999;
		int brokerServerPort=6849;
		String broker = null;
		
		if ( ic.first("broker_host") )
			broker_host = (String)ic.getValue();
		if ( ic.first("server_port") )
			brokerServerPort = Integer.parseInt((String)ic.getValue());
		
		if ( ic.first("broker_name") )
			broker = (String)ic.getValue();
		ic.delete();
		
		try {
			BrokerAdminClient aclient1 = BrokerAdminClient.newOrReconnectAdmin(broker_host + ":" + brokerServerPort, broker, 
				"BrokerUtil Admin", "admin", "venusUtil", null);
			
			aclient1.destroyBroker();
		
			aclient1.disconnectClientById("BrokerUtil Admin");
		} catch (BrokerException be) {
			System.out.println(be.toString());
			ic.insertAfter("status", be.toString());
		}
		
		ic.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getClientInfo (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getClientInfo)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required broker_host
		// [i] field:0:required broker_name
		// [i] field:0:required client_id
		// [o] field:1:required subscriptions
		// [o] field:0:required numSubs
		// [o] field:0:required clientStats
		// [o] field:0:required lastConnectSession
		// [o] field:0:required lastDisconnectSession
		IDataCursor ic = pipeline.getCursor();
		String broker_host = null;
		String broker_name = null;
		String client_id = null;
		
		if ( ic.first("broker_host") )
			broker_host = (String)ic.getValue();
		ic.delete();
		
		if ( ic.first("broker_name") )
			broker_name = (String)ic.getValue();
		ic.delete();
		
		if ( ic.first("client_id") )
			client_id = (String)ic.getValue();
		ic.delete();
		
		BrokerAdminClient client = null;
		BrokerSubscription[] subscriptions = null;
		BrokerEvent beStats = null;
		String[] subscriptionString = null;
		int i;
		String foo = null;
		try {
		//System.out.println("Before reconnecting admin client\n");
			client = BrokerAdminClient.newOrReconnectAdmin(broker_host, broker_name, "vSubMonitor", 
				"admin", "Subscription monitor", null); 
		//("2: Before getClientSubscriptionsById: broker_host: "+broker_host+"\nclient_id: "+client_id+"\n");
		
			subscriptions = client.getClientSubscriptionsById(client_id);
			beStats = client.getClientStatsById(client_id);
		//if (subscriptions.length == 0)
		//	ic.insertAfter("subscriptions", "");
		//else
		//	ic.insertAfter("subscriptions", subscriptions[subscriptions.length-1].filter);
		
		//System.out.println("3: After getClientSubscriptionsById: broker_host: "+broker_host+"\nclient_id: "+client_id+"\n");
		 
			subscriptionString = new String[subscriptions.length];
			for (i = 0; i < subscriptions.length; i++) {
				subscriptionString[i] = subscriptions[i].toString();
			}
			client.destroy();
			//client.disconnectClientById("vSubMonitor");
			ic.insertAfter("subscriptions", subscriptionString);
			ic.insertAfter("numSubs", Integer.toString(subscriptions.length));
			ic.insertAfter("clientStats", beStats.toString());
			if (beStats != null) {
			ic.insertAfter("lastConnectSession", beStats.getIntegerField("lastConnectSession"));
			ic.insertAfter("lastDisconnectSession", beStats.getIntegerField("lastDisconnectSession"));
			}
		} catch (BrokerException be) {
			ic.insertAfter("subscriptons", be.toString());
			try {
				//client.destroy();
				client.disconnectClientById("vSubMonitor");
			} catch (BrokerException be2) {
					ic.insertAfter("subscriptions", be2.toString());
			}
		}
		ic.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getEventTypeDefinition (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getEventTypeDefinition)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required broker_host
		// [i] field:0:required broker_name
		// [i] field:0:required event_type_name
		// [o] field:1:required event_types
		// [o] field:0:required event_type_definition
		IDataCursor ic = pipeline.getCursor();
		String broker_host = null;
		String broker_name = null;
		String event_type_name = null;
		
		if ( ic.first("broker_host") )
			broker_host = (String)ic.getValue();
		ic.delete();
		
		if ( ic.first("broker_name") )
			broker_name = (String)ic.getValue();
		ic.delete();
		
		if ( ic.first("event_type_name") )
			event_type_name = (String)ic.getValue();
		ic.delete();
		
		BrokerAdminClient client = null;
		BrokerTypeDef eventTypeDefinition;
		String[] eventTypes = null;
		int i;
		String foo = null;
		try {
			client = BrokerAdminClient.newOrReconnectAdmin(broker_host, broker_name, "vPSFilterMonitor", 
				"admin", "ET monitor", null); 
		
			eventTypes = client.getEventTypeNames();
			eventTypeDefinition = client.getEventTypeDef(event_type_name);	
		
			client.destroy();
			ic.insertAfter("event_types", eventTypes);
			ic.insertAfter("event_type_definition", eventTypeDefinition.toString());
		} catch (BrokerException be) {
			ic.insertAfter("event_type_definition", be.toString());
		ic.insertAfter("event_types", eventTypes);
			try {
				//client.destroy();
				client.disconnectClientById("vPSFilterMonitor");
			} catch (BrokerException be2) {
					ic.insertAfter("event_type_definition", be2.toString());
		ic.insertAfter("event_types", eventTypes);
			}
		}
		ic.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getFilterInfo (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getFilterInfo)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required broker_host
		// [i] field:0:required broker_name
		// [i] field:0:required client_id
		// [o] field:1:required subscriptions
		// [o] field:0:required numSubs
		IDataCursor ic = pipeline.getCursor();
		String broker_host = null;
		String broker_name = null;
		String client_id = null;
		
		if ( ic.first("broker_host") )
			broker_host = (String)ic.getValue();
		ic.delete();
		
		if ( ic.first("broker_name") )
			broker_name = (String)ic.getValue();
		ic.delete();
		
		if ( ic.first("client_id") )
			client_id = (String)ic.getValue();
		ic.delete();
		
		BrokerAdminClient client = null;
		BrokerSubscription[] subscriptions = null;
		String[] subscriptionString = null;
		int i;
		String foo = null;
		try {
		//System.out.println("Before reconnecting admin client\n");
			client = BrokerAdminClient.newOrReconnectAdmin(broker_host, broker_name, "vPSFilterMonitor", 
				"admin", "Filter monitor", null); 
		//("2: Before getClientSubscriptionsById: broker_host: "+broker_host+"\nclient_id: "+client_id+"\n");
		
			subscriptions = client.getClientSubscriptionsById(client_id);
			
		//if (subscriptions.length == 0)
		//	ic.insertAfter("subscriptions", "");
		//else
		//	ic.insertAfter("subscriptions", subscriptions[subscriptions.length-1].filter);
		
		//System.out.println("3: After getClientSubscriptionsById: broker_host: "+broker_host+"\nclient_id: "+client_id+"\n");
		 
			subscriptionString = new String[subscriptions.length];
			for (i = 0; i < subscriptions.length; i++) {
				subscriptionString[i] = subscriptions[i].filter;
			}
			client.destroy();
			//client.disconnectClientById("vPSFilterMonitor");
			ic.insertAfter("subscriptions", subscriptionString);
			ic.insertAfter("numSubs", Integer.toString(subscriptions.length));
		} catch (BrokerException be) {
			ic.insertAfter("subscriptons", be.toString());
			try {
				//client.destroy();
				client.disconnectClientById("vPSFilterMonitor");
			} catch (BrokerException be2) {
					ic.insertAfter("subscriptions", be2.toString());
			}
		}
		ic.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getSSLConfig (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getSSLConfig)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required broker_host
		// [i] field:0:required server_port
		// [i] field:0:required monitor_port
		// [o] field:0:required keystore
		// [o] field:0:required ksPasswd
		// [o] field:0:required ksType
		// [o] field:0:required truststore
		// [o] field:0:required tsType
		// [o] field:0:required sslProtocol
		// [o] field:0:required verifyDepth
		 IDataCursor ic = pipeline.getCursor();
		String brokerServer = null;
		String statusString = null;
		int status = -999;
		int brokerPort = 6849;
			int monitorPort = 6850;
		BrokerServerClient brokerClient = null;
		
		if ( ic.first("broker_host") )
			brokerServer = (String)ic.getValue();
		if ( ic.first("server_port") )
			brokerPort = Integer.parseInt((String)ic.getValue());
		if ( ic.first("monitor_port") )
			monitorPort = Integer.parseInt((String)ic.getValue());    
		 
		String broker = brokerServer + ":" + brokerPort;
		try {
		 BrokerConnectionDescriptor noSSLDescriptor = new BrokerConnectionDescriptor();
		        try {
		            brokerClient = new BrokerServerClient(broker, noSSLDescriptor);
		        } catch (BrokerException e) {
		            // Retry
		            BrokerServerClient.startServerProcess(broker, monitorPort, brokerPort);
		        }
		        brokerClient = new BrokerServerClient(broker, noSSLDescriptor);
		       BrokerSSLConfigV2 brokerConfig = brokerClient.getSavedSSLConfigV2();
		
		String keystore = brokerConfig.getKeystore();
		        String ksPasswd = brokerConfig.getKeystorePassword();
		        String ksType = brokerConfig.getKeystoreType().toString();
		        String truststore = brokerConfig.getTruststore();
		        String tsType = brokerConfig.getTruststoreType().toString();
		        String sslProtocol = brokerConfig.getSslProtocol().toString();
		       int verifyDepth = brokerConfig.getVerifyDepth();
		        String cipherSuites = brokerConfig.getCipherSuites();
		ic.insertAfter("keystore", keystore);
		ic.insertAfter("ksPasswd", ksPasswd);
		ic.insertAfter("ksType", ksType);
		ic.insertAfter("truststore", truststore);
		ic.insertAfter("tsType", tsType);
		ic.insertAfter("sslProtocol", sslProtocol);
		ic.insertAfter("verifyDepth", verifyDepth);
		
		        
		        } catch (BrokerException e) {ic.insertAfter("error", e.toString());}
		ic.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void setSSLConfig (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(setSSLConfig)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required broker_host
		// [i] field:0:required server_port
		// [i] field:0:required monitor_port
		// [i] field:0:required keystore
		// [i] field:0:required ksPasswd
		// [i] field:0:required ksType
		// [i] field:0:required truststore
		// [i] field:0:required tsType
		// [i] field:0:required sslProtocol
		// [i] field:0:required verifyDepth
		// [o] field:0:required status
		 IDataCursor ic = pipeline.getCursor();
		String brokerServer = null;
		String statusString = null;
		int status = -999;
		int brokerPort = 6849;
			int monitorPort = 6850;
		BrokerServerClient brokerClient = null;
		String keystore=null;
		String ksPasswd = null;
		String ksType = null;
		String truststore = null;
		String tsType = null;
		String sslProtocol = null;
		String cipherSuites = null;
		int verifyDepth = 0;
		int run_state = BrokerServerClient.SERVER_STATUS_STOPPED;
		
		if ( ic.first("broker_host") )
			brokerServer = (String)ic.getValue();
		if ( ic.first("server_port") )
			brokerPort = Integer.parseInt((String)ic.getValue());
		if ( ic.first("keystore") ) {
			keystore = (String)ic.getValue();
			File f = new File(keystore);
			keystore = f.getAbsolutePath();
		}
		if ( ic.first("ksPasswd") )
			ksPasswd =(String)ic.getValue();
		if ( ic.first("ksType") )
			ksType = (String)ic.getValue();
		if ( ic.first("truststore") ) {
			truststore = (String)ic.getValue();
			File f = new File(truststore);
			truststore = f.getAbsolutePath();
		}
		if ( ic.first("tsType") )
			tsType =(String)ic.getValue();
		if ( ic.first("sslProtocol") )
			sslProtocol =(String)ic.getValue();
		if ( ic.first("cipherSuites") )
			cipherSuites = (String)ic.getValue();
		if ( ic.first("verifyDepth") )
			verifyDepth = Integer.parseInt((String)ic.getValue());
		if ( ic.first("monitor_port") )
			monitorPort = Integer.parseInt((String)ic.getValue());
		
		try {
			BrokerSSLConfigV2 brokerConfig = new BrokerSSLConfigV2();
			brokerConfig.setKeystore(keystore);
			brokerConfig.setKeystorePassword(ksPasswd);
			brokerConfig.setKeystoreType(ksType);
			brokerConfig.setTruststore(truststore);
			brokerConfig.setTruststoreType(tsType);
			brokerConfig.setSslProtocol(sslProtocol);
			brokerConfig.setCipherSuites(cipherSuites);
		
			if (verifyDepth > 0)
				brokerConfig.setVerifyDepth(verifyDepth);
		
			String broker = brokerServer + ":" + brokerPort;
			System.out.println("Setting SSL configuration on " + broker
					+ " with keystore: " + brokerConfig.getKeystore());
		
			brokerClient = new BrokerServerClient(brokerServer + ":"
					+ brokerPort, new BrokerConnectionDescriptor());
			try {
				brokerClient.setSSLConfigV2(brokerConfig);
			} catch (Exception e) {
				System.out.println("Unable to set SSL with setSSLConfigV2: "
						+ e.getMessage());
				e.printStackTrace();
			}
		
		
			BrokerConfig.broker_stop(pipeline);			
			BrokerConfig.broker_start(pipeline);
			ic.first("status");
			ic.delete();
		
		} catch (Exception ex2) {
			ex2.printStackTrace();
		}
		
		BrokerConfig.getSSLConfig(pipeline);
		ic.destroy();
		// --- <<IS-END>> ---

                
	}
}

