Unzip this archive in the root directory of your Integration Server.

See the index.html file for usage notes . . .



