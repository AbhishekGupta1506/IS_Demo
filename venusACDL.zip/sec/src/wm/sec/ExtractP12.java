/**********************************************************************

 IMPORTANT NOTICE:  Utilities and samples shown here are not official
 parts of the Software AG product line.  These utilities and samples are
 provided strictly "as is," and are not eligible for technical support
 through Software AG Technical Services.  Software AG makes no guarantees
 or warranties pertaining to the functionality, scalability, robustness,
 or degree of testing of these utilities and samples, and assumes
 absolutely no liability for any damages relating to them.  Customers are
 strongly advised to consider these utilities and samples as "working
 examples" from which they should build and test their own solutions.
 While no support is provided, Software AG will provide limited assistance
 in using this sample software.  Please direct questions or comments on
 this software to security@softwareag.com.

 ***********************************************************************/

package wm.sec;

import iaik.asn1.ObjectID;
import iaik.pkcs.PKCSException;
import iaik.pkcs.pkcs12.AuthenticatedSafe;
import iaik.pkcs.pkcs12.CertificateBag;
import iaik.pkcs.pkcs12.KeyBag;
import iaik.pkcs.pkcs12.PKCS12;
import iaik.pkcs.pkcs12.PKCS8ShroudedKeyBag;
import iaik.pkcs.pkcs12.SafeBag;
import iaik.utils.InternalErrorException;
import iaik.x509.SimpleChainVerifier;
import iaik.x509.V3Extension;
import iaik.x509.X509Certificate;
import iaik.x509.X509ExtensionInitException;
import iaik.x509.extensions.BasicConstraints;
import iaik.x509.extensions.SubjectKeyIdentifier;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.security.InvalidKeyException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Security;
import java.security.cert.CertificateException;
import java.security.interfaces.RSAKey;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.util.Hashtable;
import java.util.logging.ConsoleHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.entrust.toolkit.security.provider.Entrust;
import com.entrust.toolkit.util.Version;

/**
 * Extract a private key and certificate file from a PKCS#12 file. This
 * currently only writes out the first private key it finds.
 */

public class ExtractP12 {

	private static final int HASHCOUNT = 2000;

	private static Logger logger = Logger.getLogger("wm.sec");

	public static void main(String[] args) throws Exception {

		ConsoleHandler ch = new ConsoleHandler();
		ch.setFormatter(new ShortFormatter());
		
		logger.setUseParentHandlers(false);
		logger.addHandler(ch);

		// Default console = INFO so need to set both logger & ch
		//		ch.setLevel(Level.FINE);
		//		logger.setLevel(Level.FINE);

		Security.addProvider(new iaik.security.provider.IAIK());
		Security.addProvider(new Entrust());

		ExtractP12 e = new ExtractP12();
		logger.warning("Version = " + Version.VERSION);

		if (args.length > 3) {
			logger.info("Running in create mode");
			e.assembleP12(args);
		} else if (args.length > 1){
			logger.info("Running in extract/info mode");
			e.process(args);
		} else {
			showUsage();
		}

	}
	
	private static final String build = "$LastChangedRevision: 2107 $";
	
	private static void showUsage() {
		String buildnum = "?";
		try {
			buildnum = build.split(" ")[1];
		} catch (RuntimeException e) {
		}
		logger.info("ExtractP12 (build " + buildnum + ")\n" +
				"Extract/info mode:\n" +
				"  java ExtractP12 <PKCS#12 file> <password> [-info]\n" +
				"Create mode:\n" +
				"  java ExtractP12 <PKCS#12 file> <password> <alias> <keyfile> <certfile> [cafile]");
				
	}

	private PKCS12 p12 = null;

	/**
	 * @param privkey -
	 *            private key
	 * @param cert -
	 *            public key certificate
	 * @param cacerts -
	 *            CA certs to include
	 * @param friendlyName -
	 *            alias name for file
	 * @param password -
	 *            password to set on P12
	 * 
	 * @return
	 */
	public Hashtable<String,String> assembleP12(java.security.PrivateKey privkey,
			X509Certificate cert, X509Certificate[] cacerts,
			String friendlyName, char[] password) {
		Hashtable<String,String> out = new Hashtable<String,String>();
		// number of baggies needed to hold certificates
		int numbags = 1;
		if (cacerts[0] != null) {
			numbags = cacerts.length + 1;
		}
		CertificateBag[] cba = new CertificateBag[numbags];
		KeyBag kb = null;

		java.security.cert.X509Certificate[] xcc = findChain(cert, cacerts);
		if (xcc != null) {
			logger.info("found CA chain");
		} else {
			logger.warning("did not find complete CA chain");
		}

		// Setting key id allows hooking up to private key later
		cba[0] = new CertificateBag(cert);
		cba[0].setFriendlyName(friendlyName);
		byte certLocalKeyid[] = getSKI(cert);
		cba[0].setLocalKeyID(certLocalKeyid);

		// Now add the chain
		for (int j = 0; j < cacerts.length; j++) {
			if (cacerts[j] != null) {
				cba[j + 1] = new CertificateBag(cacerts[j], "ca" + j,
						getSKI(cacerts[j]));
			}
		}

		// Now create a bag for the private key
		kb = new KeyBag(privkey);
		kb.setFriendlyName(friendlyName);
		kb.setLocalKeyID(certLocalKeyid);

		try {
			p12 = new PKCS12(kb, cba, HASHCOUNT);
			p12.encrypt(password);
			out.put("status", "success");
		} catch (PKCSException e) {
			out
					.put("message", "Could not create PKCS#12 file: "
							+ e.toString());
		}
		return out;
	}

	public static byte[] getSKI(X509Certificate c) {
		try {
			V3Extension vski = c.getExtension(SubjectKeyIdentifier.oid);
			if (vski != null) {
				SubjectKeyIdentifier ski = (SubjectKeyIdentifier) vski;
				return ski.get();
			} else {
				logger.info("SubjectKeyIdentifier not found in "
						+ c.getSubjectDN() + ", using fingerprint instead");
				return c.getFingerprint();
			}

		} catch (X509ExtensionInitException e) {
			logger.log(Level.INFO, "Could not process SKI in "
					+ c.getSubjectDN(), e);
		}
		return null;
	}

	/**
	 * Create a basic PKCS12 object from constituent parts. This format is known
	 * to be importable into Mozilla/IE.
	 * 
	 * @param pkfile
	 *            Private Key file (unencrypted)
	 * @param certfile
	 *            Certificate file
	 * @param cafile
	 *            CA file (optional)
	 * @param friendlyName
	 * @param password
	 * @return PKCS12 object
	 * @throws CertKitException
	 */
	public Hashtable<String,String> assembleP12(String pkfile, String certfile, String cafile,
			String friendlyName, char[] password) {
		Hashtable<String,String> out = new Hashtable<String,String>();
		X509Certificate cert;
		RSAPrivateKey pk;
		try {
			logger.info("Loading cert: " + certfile);
			cert = new X509Certificate(new FileInputStream(certfile));

			// TODO: Allow multiple CA certs
			X509Certificate[] cacerts = new X509Certificate[1];
			if (cafile != null && !cafile.equals("")) {
				logger.info("Loading CA certificate: " + cafile);
				cacerts[0] = new X509Certificate(new FileInputStream(cafile));
			}

			logger.info("Loading private key file: " + pkfile);
			FileInputStream fis = new FileInputStream(pkfile);
			byte[] pkarray = new byte[fis.available()];
			fis.read(pkarray);
			pk = null;
			try {
				pk = new iaik.security.rsa.RSAPrivateKey(pkarray);
			} catch (InvalidKeyException ike) {
				logger.info("invalid private key, must be pkcs#8");
			}

			BigInteger prkm = pk.getModulus();
			PublicKey cpk = cert.getPublicKey();
			if (cpk instanceof RSAKey) {
				RSAKey rsakey = (RSAKey) cpk;
				BigInteger pukm = rsakey.getModulus();
				if (prkm.compareTo(pukm) == 0) {
					logger
							.info("Matching key/cert moduli found (this is good)");
				} else {
					logger.info("Public/private keys to not match, aborting");
					return out;
				}
			} else {
				logger.warning("Not an RSA key, this can't be good.");
			}

			out = assembleP12(pk, cert, cacerts, friendlyName, password);
		} catch (CertificateException e) {
			logger.log(Level.WARNING, "Error loading cert", e);
			out.put("message", "CertificateException: " + e.toString());
		} catch (FileNotFoundException e) {
			out.put("message", "File Not Found: " + e.toString());
		} catch (IOException e) {
			out.put("message", "IOException: " + e.toString());
		}
		return out;
	}

	private Hashtable<String,String> assembleP12(String[] args) {

		Hashtable<String,String> out = new Hashtable<String,String>();

		if (args.length < 5) {
			showUsage();
			out.put("status", "aborted");
			return out;
		}

		String p12file = args[0];
		String password = args[1];
		String alias = args[2];
		String keyfile = args[3];
		String certfile = args[4];

		String cafile = null;
		if (args.length >= 6) {
			cafile = args[5];
		}

		File p12out = new File(p12file);

		if (p12out.exists()) {
			logger.warning("p12file " + p12file + " exists, aborting");
			out.put("status", "failed");
			return out;
		}

		out = assembleP12(keyfile, certfile, cafile, alias, password
				.toCharArray());
		// TODO: write status:

		String status = (String) out.get("status");
		String message = (String) out.get("message");
		if (status != null) {
			logger.info("status = " + status);
		}
		if (message != null) {
			logger.info("message= " + message);
		}

		if (status != null) {

			FileOutputStream p12os;
			try {
				p12os = new FileOutputStream(p12out);
				p12.writeTo(p12os);
				p12os.close();
				logger.info("Successfully wrote " + p12file);
			} catch (Exception e) {
				logger.log(Level.WARNING, "could not write p12", e);
				out.put("status", "failed to write p12");
			}

		} else {
			logger.warning("Failed to create p12");
		}

		return out;
	}

	/**
	 * @param leaf -
	 *            EE certificate
	 * @param certArray -
	 *            array of potential CA certificates
	 */
	public java.security.cert.X509Certificate[] findChain(X509Certificate leaf,
			X509Certificate[] certArray) {
		try {
			java.security.cert.X509Certificate cc[] = SimpleChainVerifier
					.orderCertificateChain(leaf, certArray);
			logger.fine("  Found chain to root CA:");
			for (int i = 0; i < cc.length; i++) {
				logger.fine("   " + cc[i].getSubjectDN().getName());
			}
			return cc;
		} catch (CertificateException e) {
			logger.fine("  Could not build complete certificate chain.");
		}
		return null;
	}

	final byte[] findkey(PKCS12 p12, X509Certificate c, int index) {

		// Search the whole p12 to find a matching key.
		// TODO: Find a PKCS#12 that uses DSA keys

		RSAPublicKey pubkey;
		try {
			pubkey = (RSAPublicKey) c.getPublicKey();
		} catch (ClassCastException cce) {
			logger.severe(" Non-RSA keys not supported currently.");
			return null;
		}

		AuthenticatedSafe as[] = p12.getAuthenticatedSafes();
		// int pkcount = 0;
		for (int asi = 0; asi < as.length; asi++) {
			SafeBag sb[] = as[asi].getSafeBags();
			for (int sbi = 0; sbi < sb.length; sbi++) {
				if (sb[sbi].getBagType().equals(
						ObjectID.pkcs12_pkcs8ShroudedKeyBag)) {
					PKCS8ShroudedKeyBag kb = (PKCS8ShroudedKeyBag) sb[sbi];
					RSAPrivateKey pk = (RSAPrivateKey) kb.getPrivateKey();
					if (pubkey.getModulus().compareTo(pk.getModulus()) == 0) {
						return (pk.getEncoded());
					}
				}
			}
		}

		return null;
	}

	final X509Certificate[] getChain(PKCS12 p12) {
		return CertificateBag.getCertificates(p12.getCertificateBags());
	}

	final PrivateKey getPrivateKey(PKCS12 p12) {
		return p12.getKeyBag().getPrivateKey();
	}

	/**
	 * @param args,
	 *            arg[0] = pkcs12 file, arg[1] = password, arg[2] = -info if you
	 * want to just look @ p12
	 * @return
	 */
	public boolean process(String[] args) {

		if (args.length < 2) {
			showUsage();
			return false;
		}

		logger.info("Running in extract mode");

		FileInputStream fis;
		try {
			fis = new FileInputStream(args[0]);
		} catch (FileNotFoundException fe) {
			logger.warning("could not load p12 file: " + args[0]);
			return false;
		}

		char[] password = args[1].toCharArray();

		PKCS12 store;
		try {
			store = new PKCS12(fis);
			try {
				store.skipUnsupportedSafeBags(true);
			} catch (NoSuchMethodError nsme) {
				// ignore for pre 6.1 Entrust
			}
			store.verify(password);
			store.decrypt(password);
		} catch (iaik.pkcs.PKCSParsingException pe) {
			logger.warning("Error parsing P12 file:" + pe);
			return false;
		} catch (iaik.pkcs.PKCSException pke) {
			logger.warning("Error decrypting P12 file (bad password?): " + pke);
			return false;
		} catch (ClassCastException cce) {
			logger.warning("ClassCastException reading file (is this really a PKCS#12 file?)");
			return false;
		} catch (InternalErrorException ie) {
			logger.warning("Internal Error reading PKCS#12 (unlimited policy file not installed?)");
			return false;
		} catch (IOException io) {
			logger.warning("I/O exception reading PKCS#12 file: " + io);
			return false;
		}

		// lame
		if (args.length == 3 && args[2].equalsIgnoreCase("-info")) {
			logger.info(store.toString());
			logger.info("skipping extract since in info mode");
			return false;
		}

		// Write out the certificate to default filename
		X509Certificate[] chain = getChain(store);
		String certFile = null;

		boolean root;
		boolean ca;

		for (int i = 0; i < chain.length; i++) {
			root = false;
			ca = false;

			logger.info("Processing certificate " + i);

			X509Certificate c = chain[i];

			// Check if root CA
			if (c.getSubjectDN().equals(c.getIssuerDN())) {
				root = true;
				// Set CA true since some old root CAs are V1
				ca = true;
				logger.info(" Found root CA certificate");
			}

			// Determine if this is a CA certificate
			try {
				BasicConstraints bc = (BasicConstraints) c
						.getExtension(BasicConstraints.oid);
				if (bc != null) {
					ca = bc.ca();
				} else {

					// don't care, probably a end entity certificate
				}
			} catch (X509ExtensionInitException e) {
				logger.info(" No basic extension found, V1 certificate?");
			}

			try {
				if (!ca) {
					certFile = "mycert" + i + ".der";
					logger.info(" Writing end user certificate to " + certFile);
					byte[] key = findkey(store, c, i);
					if (key != null) {
						String keyfile = "mypk" + i + ".der";
						logger.info(" Writing end user private key to " + keyfile);
						FileOutputStream keyFos = new FileOutputStream(keyfile);
						keyFos.write(key);
						keyFos.close();
					} else {
						logger.info(" Matching private key not found.");
					}
					findChain(c, chain);
				} else if (!root) {
					certFile = "myca" + i + ".der";
					logger.info(" Writing intermediate CA certificate to " + certFile);
				} else {
					certFile = "myrootca" + i + ".der";
					logger.info(" Writing root CA certificate to " + certFile);
					if (c.getVersion() == 1) {
						logger.info(" Version 1 CA, checking for private key (i.e., self-signed)");
						byte[] key = findkey(store, c, i);
						if (key != null) {
							String keyfile = "mypk" + i + ".der";
							logger.info(" Writing end user private key to " + keyfile);
							FileOutputStream keyFos = new FileOutputStream(
									keyfile);
							keyFos.write(key);
							keyFos.close();
						}
					}
				}
				FileOutputStream certFos = new FileOutputStream(certFile);

				logger.fine(" Subject = " + c.getSubjectDN().getName());
				logger.fine(" Issuer  = " + c.getIssuerDN().getName());
				chain[i].writeTo(certFos);
				certFos.close();

			} catch (IOException io) {
				logger.warning("Error writing file (" + certFile + "):\n"
						+ io.toString());
				return false;
			}
		}
		return true;
	}



}