package wm.sec;

import java.io.File;
import java.io.FilenameFilter;

/**
 * Filter to select typical certificate files
 */
public class CertFilter implements FilenameFilter {
	public boolean accept(File dir, String name) {
		return (name.endsWith(".pem") || (name.endsWith(".der") || (name
				.endsWith(".cer"))));
	}
}
