package wm.sec;

import java.text.DateFormat;
import java.util.logging.Formatter;
import java.util.logging.LogRecord;

public class ShortFormatter extends Formatter {
	
	public String format(LogRecord record) {
		StringBuffer sb = new StringBuffer();

		sb.append("[");
		sb.append(record.getSourceMethodName());
		sb.append("] ");
		sb.append(record.getMessage());
		sb.append("\n");
		
		Throwable t = record.getThrown();
		if (t != null) {
			sb.append(record.getThrown());
			sb.append("\n");
		}

		return sb.toString();
	}
	
	public String getd() {
		DateFormat df = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.MEDIUM);
		return df.format(new java.util.Date());
	}
}