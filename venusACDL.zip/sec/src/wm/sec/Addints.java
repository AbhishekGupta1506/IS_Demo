/**********************************************************************

 This is a modified sample IS client that shows how to enable SSL
 debug and use of a keystore instead of separate key/cert files.

 IMPORTANT NOTICE:  Utilities and samples shown here are not official
 parts of the Software AG product line.  These utilities and samples are
 provided strictly "as is," and are not eligible for technical support
 through Software AG Technical Services.  Software AG makes no guarantees
 or warranties pertaining to the functionality, scalability, robustness,
 or degree of testing of these utilities and samples, and assumes
 absolutely no liability for any damages relating to them.  Customers are
 strongly advised to consider these utilities and samples as "working
 examples" from which they should build and test their own solutions.
 While no support is provided, Software AG will provide limited assistance
 in using this sample software.  Please direct questions or comments on
 this software to security@softwareag.com.

 ***********************************************************************/

package wm.sec;

import iaik.security.ssl.KeyAndCert;

import java.io.IOException;
import java.util.logging.ConsoleHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.wm.app.b2b.client.Context;
import com.wm.app.b2b.client.KacSetter;
import com.wm.app.b2b.client.ServiceException;
import com.wm.app.b2b.util.GenUtil;
import com.wm.data.IData;
import com.wm.data.IDataCursor;
import com.wm.data.IDataFactory;

public class Addints {

	public static Logger logger = Logger.getLogger("wm.sec");
	
	public static void main(String[] args) {
		
		// TODO: Accept as args
		// TODO: Cleanup input/output stuff
		
		String server = "alta:5743";
		String kstore = "testuser1.p12";
		// Storing password securely left as exercise for the user!
		String pw = "password";
		String folder = "pub.math";
		String service = "addInts";
		boolean ssldebug = true;
	
		ConsoleHandler ch = new ConsoleHandler();
		ch.setFormatter(new ShortFormatter());
		
		logger.setUseParentHandlers(false);
		logger.addHandler(ch);
		
		// enable client debug, this must be set before calling
		//   new Context();
		logger.info("SSL debug = " + ssldebug);
		System.setProperty("watt.ssl.iaik.debug", Boolean.toString(ssldebug));
		
		// Enable SSL
		Context context = new Context();

		// Load up from keystore instead of setting from separate files
		logger.info("Loading keystore");
		KeyAndCert kac = KacSetter.getKAC(kstore, pw
				.toCharArray(), "");
		//KacSetter.setKac(context, kac);
		context.setSSLCertificates(kac);
		context.setSecure(true);

		// Set username and password for protected services
		/// Not necessary if using client cert
		String username = "Administrator";
		
		String password = "manage";

		try {
			logger.info("Connecting to " + server);
			context.connect(server, username, password);
		} catch (ServiceException e) {
			logger.info("\n\tCannot connect to server \"" + server
					+ "\"");
			System.exit(0);
		}
		logger.info("Connected to " + context.getConnectedServer());

		try {
			// Collect inputs (top-level only)
			IData inputDocument = getInputs();

			// *** Invoke the Service and Disconnect ***
			IData outputDocument = invoke(context, folder, service, inputDocument);
			context.disconnect();
			logger.info("\n********* Successful invoke **********");

			// *** Access the Results ***
			logger.info("\n************* Inputs *****************");
			GenUtil.printRec(inputDocument, "AddIntsInput");

			logger.info("\n************* Outputs *****************");
			GenUtil.printRec(outputDocument, "AddIntsOutput");

		} catch (IOException e) {
			logger.log(Level.WARNING, "IOE", e);
		} catch (ServiceException e) {
			logger.log(Level.WARNING, "ServiceException", e);
		}
		logger.info("All done");
		System.exit(0);
	}

	// *** Collect Inputs *** //
	public static IData getInputs() throws IOException, ServiceException {
		return AddIntsInput_getInputs();
	}

	public static IData AddIntsInput_getInputs() throws IOException,
			ServiceException {
		IData out = IDataFactory.create();
		IDataCursor idc = out.getCursor();
		idc.insertAfter("num1", getString("num1"));
		idc.insertAfter("num2", getString("num2"));
		idc.destroy();
		return out;
	}

	public static IData AddIntsOutput_getInputs() throws IOException,
			ServiceException {
		IData out = IDataFactory.create();
		IDataCursor idc = out.getCursor();
		idc.insertAfter("value", getString("value"));
		idc.destroy();
		return out;
	}

	public static String getString(String name) throws IOException,
			ServiceException {
		logger.info(name + " =");
		//return (new BufferedReader(new InputStreamReader(System.in))).readLine();
		return "2";
	}
	
	public static IData invoke(Context context, String folder, String service, IData inputDocument)
			throws IOException, ServiceException {
		IData out = context.invoke(folder, service, inputDocument);
		IData outputDocument = out;
		return outputDocument;
	}
}
