package wm.sec;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class X509CertUtil {

	static Logger logger = Logger.getLogger(X509CertUtil.class.getName());

	public static X509Certificate[] loadCertArray(String cadir) {
		if (cadir == null) {
			logger.warning("Null directory passed to loadCertArray");
			return null;
		}

		File f = new File(cadir);

		if (f.isFile()) {
			if (f.toString().endsWith(".jks")) {
				logger.warning("load from jks not implemented");
				return null;
			}
			logger.fine("Attempting to load single CA");

			try {
				X509Certificate xc = loadCert(f);
				X509Certificate[] z = { xc };
				return z;
			} catch (Exception e) {
				logger.warning("Exception loading CA: " + e);
				return null;
			}

		} else if (f.isDirectory()) {
			logger.info("Loading certificates from " + f.getName());
			// TODO: turn CertFilter into anon class
			String[] certfiles = f.list(new CertFilter());
			ArrayList<X509Certificate> v = new ArrayList<X509Certificate>();
			X509Certificate c;
			for (int i = 0; i < certfiles.length; i++) {
				logger.fine(" Loading " + certfiles[i]);
				try {
					c = loadCert(f + File.separator + certfiles[i]);
					if (c != null) {
						v.add(c);
					}
				} catch (Exception e) {
					logger.warning("Exception loading " + certfiles[i] + ": "
							+ e);
				}

			}
			if (v.size() > 0) {
				logger.info("# of trust roots = " + v.size());
				X509Certificate[] xc = new X509Certificate[v.size()];
				for (int i = 0; i < v.size(); i++) {
					xc[i] = (X509Certificate) v.get(i);
				}
				return xc;
			}
		} else {
			logger.warning("bad cadir? " + cadir);
		}
		return null;
	}

	public static X509Certificate[] loadX509fromPEM(String cadir) {
		logger.warning("Load PEM not implemented");
		return null;
	}

	/**
	 * @param cert
	 *            - a byte array containing a certificate
	 * @return X509Certificate
	 * @throws Exception
	 */
	public static X509Certificate loadCert(byte[] b) {
		ByteArrayInputStream bais = new ByteArrayInputStream(b);
		return loadCert(bais);
	}

	/**
	 * Load a certificate from a filename, if file doesn't exist, attempt to
	 * load as PEM string
	 * 
	 * @param certfile
	 * @return iaik.x509.X509Certificate
	 * @throws IOException
	 */
	public static X509Certificate loadCert(String f) {
		File cf = new File(f);
		X509Certificate xc = null;
		logger.info("File = " + cf.getAbsolutePath());
		if (cf.exists()) {
			xc = loadCert(cf);
		} else {
			if (f.startsWith("-----BEGIN")) {
				xc = loadCert(f.getBytes());
			} else {
				logger.info(f + " not found");
			}
		}
		return xc;
	}

	/**
	 * Load certificate from file
	 * 
	 * @param certfile
	 * @return iaik.x509.X509Certificate
	 * @throws Exception
	 */
	public static X509Certificate loadCert(File f) {
		try {
			FileInputStream fis = new FileInputStream(f);
			return loadCert(fis);
		} catch (FileNotFoundException e) {
			logger.log(Level.WARNING, "File " + f + " not found", e);
		}
		return null;

	}

	/**
	 * Load certificate from InputStream
	 * 
	 * @param certInputStream
	 * @return iaik.x509.X509Certificate
	 * @throws Exception
	 */
	public static X509Certificate loadCert(InputStream f) {

		CertificateFactory cf = null;
		try {
			cf = CertificateFactory.getInstance("X.509", "IAIK");
		} catch (CertificateException e1) {
			logger.warning("CertificateException getting X.509 generator");
			return null;
		} catch (NoSuchProviderException e1) {
			logger.warning("IAIK provider not found.");
			return null;
		}

		Certificate c = null;
		try {
			c = cf.generateCertificate(f);
			f.close();
		} catch (CertificateException e) {
			logger.warning("Exception loading cert " + e.toString());
		} catch (IOException e) {
			logger.log(Level.WARNING, "Exception loading cert", e);
		}
		X509Certificate xc = (X509Certificate) c;
		return xc;
	}

	/**
	 * Load a certificate
	 * 
	 * @param o
	 * @return
	 * @throws Exception
	 */
	public static X509Certificate loadCert(Object o)
			throws CertificateException {
		if (o instanceof File) {
			return loadCert((File) o);
		} else if (o instanceof byte[]) {
			return loadCert((byte[]) o);
		} else if (o instanceof String) {
			return loadCert((String) o);
		} else if (o instanceof InputStream) {
			return loadCert((InputStream) o);
		} else {
			throw new CertificateException("Can't load cert from "
					+ o.getClass().getName());
		}
	}

	public static KeyStore loadKS(String ksfile, String pw) throws IOException {
		KeyStore ks = null;
		String kstype = "";
		logger.info("Logging in to keystore: " + ksfile);
		if (ksfile.endsWith(".p12") || ksfile.endsWith(".pfx")) {
			logger.info("Loading P12 file: " + ksfile);
			kstype = "pkcs12";
		} else if (ksfile.endsWith(".p11")) {
			logger.warning("pkcs#11 not implemented yet");
		} else {
			logger.info("Defaulting to JKS file: " + ksfile);
			kstype = "jks";
		}

		try {
			ks = KeyStore.getInstance(kstype);
			FileInputStream fis = new FileInputStream(ksfile);
			if (pw == null) {
				ks.load(fis, null);
			} else {
				ks.load(fis, pw.toCharArray());
			}
			logger.info("loaded keystore " + ksfile);
			fis.close();
			return ks;
		} catch (KeyStoreException e) {
			logger.log(Level.WARNING, "KeyStore Exception loading keystore"
					+ ksfile, e);
		} catch (FileNotFoundException e) {
			throw e;
		} catch (NoSuchAlgorithmException e) {
			logger.log(Level.WARNING,
					"NoSuchAlgorithmException loading keystore" + ksfile, e);
		} catch (CertificateException e) {
			logger.log(Level.WARNING, "CertificateException loading keystore"
					+ ksfile, e);
		}
		return ks;
	}

	static Pattern reasonPattern = Pattern.compile(".*revoked, reason: (.*)");

	/*
	 * This horrible method is required since Sun's revocation checker doesn't
	 * surface the revocation reason
	 */
	public static String parseValidatorException(String msg) {
		Matcher m = reasonPattern.matcher(msg);
		boolean b = m.matches();
		if (b && m.groupCount() == 1) {
			String reason = m.group(1);
			logger.info("found reason " + reason);
			return reason;
		} else {
			logger.info("No revocation reason found");
		}
		return null;
	}
}
