package wm.sec;

import iaik.asn1.ASN1Object;
import iaik.asn1.ObjectID;
import iaik.asn1.structures.AlgorithmID;
import iaik.asn1.structures.Attribute;
import iaik.asn1.structures.GeneralName;
import iaik.asn1.structures.GeneralNames;
import iaik.asn1.structures.Name;
import iaik.pkcs.pkcs10.CertificateRequest;
import iaik.security.rsa.RSAPrivateKey;
import iaik.utils.RFC2253NameParser;
import iaik.x509.X509Certificate;
import iaik.x509.X509Extensions;
import iaik.x509.extensions.SubjectAltName;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertPath;
import java.security.cert.Certificate;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.logging.Level;
import java.util.logging.Logger;

import sun.misc.BASE64Encoder;
import sun.security.tools.KeyTool;

import com.entrust.toolkit.security.provider.Initializer;

public class Csrutil {

	private static final String PKCS12 = "pkcs12";

	private static final String JKS = "jks";

	private static Logger logger = Logger.getLogger(Csrutil.class.getName());

	KeyStore ks;
	String kstype = "pkcs12";
	String dnSuffix = ",ou=rnd-security,o=sag";
	String keysize = "1024";

	public static void main(String[] args) {

		Initializer.getInstance().setProviders(Initializer.MODE_NORMAL);

		// create host password domain
		// gencsr host password
		// import host password certfile
		// pem host password

		if (args.length < 3) {
			usage();
		} else {
			String cmd = args[0];
			String host = args[1];
			char[] pw = args[2].toCharArray();
			Csrutil cu = new Csrutil();
			if (cmd.equalsIgnoreCase("create")) {
				cu.createKeystore(host, pw);
			} else if (cmd.equalsIgnoreCase("gencsr")) {
				if (args.length < 4) {
					usage();
				}
				String domain = args[3];
				cu.genCSR(host, domain, pw);
			} else if (cmd.equalsIgnoreCase("import")) {
				if (args.length < 4) {
					usage();
				}
				String certfile = args[3];
				cu.importCert(host, certfile, pw);
			} else if (cmd.equalsIgnoreCase("export")) {
				cu.export(host, pw, true);
			} else if (cmd.equalsIgnoreCase("exportbin")) {
				cu.export(host, pw, false);
			} else if (cmd.equalsIgnoreCase("list")) {
				cu.list(host, pw);
			} else if (cmd.equalsIgnoreCase("chain")) {
				cu.createChain(args[1], args[2], args[3], args[4]);
			}
		}

	}

	private void list(String host, char[] pw) {

		try {
			load(host, pw);
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Exception loading keystore", e);
			return;
		}

		try {
			Enumeration<String> aliases = ks.aliases();
			for (; aliases.hasMoreElements();) {
				String alias = aliases.nextElement();
				logger.info("alias = " + alias);

				Certificate[] c = ks.getCertificateChain(alias);
				if (c == null) {
					c = new Certificate[1];
					c[0] = ks.getCertificate(host);
				}

				for (int i = 0; i < c.length; i++) {
					try {
						X509Certificate xc = new X509Certificate(c[i]
								.getEncoded());
						logger.info(xc.toString(true));
					} catch (CertificateEncodingException e) {
						logger.log(Level.WARNING, "cee", e);
					} catch (CertificateException e) {
						logger.log(Level.WARNING, "ce", e);
					}

				}

				try {
					Key k = ks.getKey(alias, pw);
					if (k != null) {
						logger.info("private key found = " + k.getAlgorithm() + "/"
								+ k.getFormat());
						if (k.getFormat().equalsIgnoreCase("PKCS#8")) {
							RSAPrivateKey pk = new RSAPrivateKey(k.getEncoded());
							logger.info("pk modulus = " + pk.getModulus().toString(16));
						}
					}
				} catch (UnrecoverableKeyException e) {
					logger.log(Level.INFO, "uke", e);
				} catch (NoSuchAlgorithmException e) {
					logger.log(Level.INFO, "nsae", e);
				} catch (InvalidKeyException e) {
					logger.log(Level.INFO, "ike", e);
				}
			}
		} catch (KeyStoreException e) {
			logger.log(Level.INFO, "kse", e);
		}

	}

	private static void usage() {
		System.err.println("csrutil create|gencsr|import|list|export");
		System.err
				.println(" create host pw - create a pkcs12 keystore for host");
		System.err
				.println(" list host pw - list a pkcs12/jks keystore for host");
		System.err
				.println(" gencsr host pw domain - create a CSR for host.domain name");
		System.err.println("   *** get your CA to sign your CSR ***");
		System.err
				.println(" chain host cert intca rootca - generate pkcs7 chain ");
		System.err
				.println("   *** you must have intermediate&root CA certs ***");
		System.err
				.println(" import host pw certfile - import a cert chain to pkcs12");
		System.err.println(" export host pw - export PEM (apache)");

	}

	private void load(String host, char[] pw) throws Exception {

		String ksfile = host + ".p12";
		File f = new File(ksfile);
		if (f.exists()) {
			kstype = PKCS12;
		} else {
			ksfile = host;
			f = new File(ksfile);
			if (f.exists()) {
				if (ksfile.endsWith(".p12")) {
					kstype = PKCS12;
				} else if (ksfile.endsWith(".jks")) {
					kstype = JKS;
				}
			} else {
				logger.log(Level.SEVERE, "Keystore file does not exist: "
						+ ksfile);
				return;
			}
		}

		logger.info("Loading " + ksfile);
		ks = KeyStore.getInstance(kstype);
		FileInputStream fis = new FileInputStream(ksfile);
		ks.load(fis, pw);
		fis.close();
	}

	public void createKeystore(String host, char[] pw) {

		String ksfile = host + ".p12";
		String[] args = { "-v", "-genkey", "-alias", host, "-keyalg", "rsa",
				"-keysize", keysize, "-storetype", kstype, "-keystore", ksfile,
				"-dname", "cn=" + host, "-storepass", new String(pw) };
		try {
			KeyTool.main(args);
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Exception creating keystore", e);
		}
	}

	public void genCSR(String host, String domain, char[] pw) {
		try {
			load(host, pw);

			PrivateKey pk = (PrivateKey) ks.getKey(host, pw);
			Certificate c = ks.getCertificate(host);

			logger.info("Creating the CertificateRequest... ");
			Name subjectDN = new RFC2253NameParser("cn=" + host + dnSuffix)
					.parse();

			CertificateRequest certReq = new CertificateRequest(c
					.getPublicKey(), subjectDN);

			// Create SubjectAltName fields
			GeneralNames gns = new GeneralNames();
			GeneralName gns1 = new GeneralName(GeneralName.dNSName, host);
			gns.addName(gns1);
			gns1 = new GeneralName(GeneralName.dNSName, host + "." + domain);
			gns.addName(gns1);

			// Will this work?
			// String ipaddr = "127.0.0.1";
			// gns1 = new GeneralName(GeneralName.iPAddress, ipaddr );
			// gns1 = new GeneralName(GeneralName.rfc822Name, "test@y.edu");
			// gns.addName(gns1);

			SubjectAltName san = new SubjectAltName(gns);

			// And create the extensionRequest
			X509Extensions exts = new X509Extensions();
			exts.addExtension(san);

			ASN1Object[] asn1Objects = new ASN1Object[] { exts.toASN1Object() };
			Attribute a = new Attribute(ObjectID.extensionRequest, asn1Objects);
			certReq.addAttribute(a);

			// Assumes RSA
			certReq.sign(AlgorithmID.sha1WithRSAEncryption, pk);

			logger.info("CSR = \n" + certReq.toString());
			byte[] cr = certReq.toByteArray();

			System.out.println("SubjectAltNames = \n" + san + "\n");

			System.out.println("Copy the following into the CA form:\n");

			System.out.println("-----BEGIN CERTIFICATE REQUEST-----");
			BASE64Encoder b64e = new BASE64Encoder();
			String out = b64e.encode(cr);
			System.out.println(out);
			System.out.println("-----END CERTIFICATE REQUEST-----");

		} catch (Exception e) {
			logger.log(Level.WARNING, "ex generating CSR", e);
		}
	};

	public void importCert(String host, String certfile, char[] pw) {
		String ksfile = host + ".p12";
		String[] args = { "-import", "-v", "-alias", host, "-storetype",
				kstype, "-keystore", ksfile, "-storepass", new String(pw),
				"-file", certfile };
		try {
			KeyTool.main(args);
		} catch (Exception e) {
			logger.log(Level.SEVERE, "Exception creating keystore", e);
		}
	}

	public void createChain(String host, String certfile, String intca,
			String root) {

		boolean pemmode = false;
		logger.info("Generating chain");
		byte[] p7b = genChain(certfile, intca, root);
		logger.info("Built chain, creating pkcs7 output file");
		String p7out = host + ".p7b";
		if (p7b != null) {
			try {
				FileOutputStream p7f = new FileOutputStream(p7out);

				if (pemmode) {
					p7f.write("----BEGIN PKCS7-----".getBytes());
					BASE64Encoder b64e = new BASE64Encoder();
					String out = b64e.encode(p7b);
					p7f.write(out.getBytes());
					p7f.write("----END PKCS7-----".getBytes());
				} else {
					p7f.write(p7b);
				}
				logger.info("Wrote " + p7out);
				p7f.close();
			} catch (FileNotFoundException e) {
				logger.log(Level.SEVERE, "file not found", e);
			} catch (IOException e) {
				logger.log(Level.SEVERE, "IO exception:", e);
			}

		}

	}

	public byte[] genChain(String certfile, String intca, String root) {
		logger.info("building p7b chain");
		ArrayList<java.security.cert.X509Certificate> cc = new ArrayList<java.security.cert.X509Certificate>();
		java.security.cert.X509Certificate c;
		c = loadCert(certfile);
		if (c != null) {
			cc.add(c);
		}
		c = loadCert(intca);
		if (c != null) {
			cc.add(c);
		}
		c = loadCert(root);
		if (c != null) {
			cc.add(c);
		}
		try {
			CertificateFactory cf = CertificateFactory.getInstance("X.509");
			CertPath cp = cf.generateCertPath(cc);
			// does not preserve certificate order?
			byte[] chain = cp.getEncoded("PKCS7");
			return chain;

		} catch (Exception e) {
			logger.log(Level.WARNING, "exception building chain:", e);
		}
		return null;
	}

	private java.security.cert.X509Certificate loadCert(String certfile) {
		try {
			return X509CertUtil.loadCert(certfile);
		} catch (Exception ioe) {
			logger.log(Level.WARNING, "Exception loading: " + certfile, ioe);
		}
		return null;
	}

	public void export(String host, char[] pw, boolean pemformat) {
		try {
			load(host, pw);
			String alias = host;
			if (!ks.containsAlias(host)) {
				Enumeration<String> a = ks.aliases();
				alias = a.nextElement();
				logger.fine("did not find alias " + host + ", trying " + alias);
			}
			Certificate[] c = ks.getCertificateChain(alias);
			if (c == null) {
				c = new Certificate[1];
				c[0] = ks.getCertificate(host);
			}
			BASE64Encoder b64e = new BASE64Encoder();

			for (int i = 0; i < c.length; i++) {
				if (pemformat) {
					System.out.println("-----BEGIN CERTIFICATE-----");
					String crt = b64e.encode(c[i].getEncoded());
					System.out.println(crt);
					System.out.println("-----END CERTIFICATE-----");
				} else {
					X509Certificate xc = new X509Certificate(c[i].getEncoded());
					logger.info("xc = " + xc.getSubjectDN());
					if (xc.isSelfSigned()) {
						logger.info(" is root CA");
					}
					String certout;
					if (i == 0) {
						certout = alias + "cert.der";
					} else {
						certout = alias + "ca" + i + "cert.der";
					}
					File f = new File(certout);
					FileOutputStream fos = new FileOutputStream(f);
					fos.write(xc.getEncoded());
					logger.info("Wrote cert " + i + " to " + certout);
				}
			}

			PrivateKey k = (PrivateKey) ks.getKey(alias, pw);
			if (k != null) {
				if (pemformat) {
					System.out.println("-----BEGIN PRIVATE KEY-----");
					String keyout = b64e.encode(k.getEncoded());
					System.out.println(keyout);
					System.out.println("-----END PRIVATE KEY-----");
				} else {
					String keyout = alias + "pk.der";
					File f = new File(keyout);
					FileOutputStream fos = new FileOutputStream(f);
					fos.write(k.getEncoded());
					logger.info("Wrote private key to " + keyout);
				}
			} else {
				logger.info("No private key for alias " + alias);
			}

		} catch (Exception e) {
			logger.log(Level.WARNING, "Exception exporting key", e);
		}

	};

}
