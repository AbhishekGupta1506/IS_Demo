package wm.sec;

import java.io.File;
import java.io.FileInputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Awcert {

	public static Logger logger = Logger.getLogger("wm.sec");

	private String awcertks;

	private byte[] password;

	private boolean loggedIn;

	public static void main(String[] args) {

		String awcertks = "sec/lh1.ks";
		String password = "password";

		Awcert awc = new Awcert(awcertks, password);

		logger.info("logging in to " + awcertks);

		try {
			awc.login();
		} catch (Exception e) {
			logger.log(Level.WARNING, "login error", e);
		}
	}

	public Awcert(String file, String password) {
		awcertks = file;
		this.password = password.getBytes();
	}

	public void login() throws Exception {
		if (awcertks == null || password == null)
			throw new Exception("keystore not initialized");
		File f = new File(awcertks);
		if (f.canRead()) {
			throw new Exception("can't read keystore file");
		}
		
		FileInputStream fis = new FileInputStream(f);
		
		byte[] sfheader = new byte[]
		fis.read(sfheade

	}
}
