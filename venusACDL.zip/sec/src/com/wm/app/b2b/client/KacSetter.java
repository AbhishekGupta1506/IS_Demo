/**********************************************************************

 IMPORTANT NOTICE:  Utilities and samples shown here are not official
 parts of the Software AG product line.  These utilities and samples are
 provided strictly "as is," and are not eligible for technical support
 through Software AG Technical Services.  Software AG makes no guarantees
 or warranties pertaining to the functionality, scalability, robustness,
 or degree of testing of these utilities and samples, and assumes
 absolutely no liability for any damages relating to them.  Customers are
 strongly advised to consider these utilities and samples as "working
 examples" from which they should build and test their own solutions.
 While no support is provided, Software AG will provide limited assistance
 in using this sample software.  Please direct questions or comments on
 this software to security@softwareag.com.

 ***********************************************************************/

// This is a helper class to workaround limitation in the BaseContext API

package com.wm.app.b2b.client;

import java.io.FileInputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.Certificate;
import java.util.Enumeration;
import java.util.logging.Level;
import java.util.logging.Logger;

import iaik.security.ssl.KeyAndCert;
import iaik.x509.X509Certificate;

public class KacSetter {

	private static Logger logger = Logger.getLogger("wm.sec");
	
	@Deprecated	
	public static void setKac(Context c, KeyAndCert kac) {
		c.gSSLCredentials = (Object)kac;
	}
	
	public static KeyAndCert getKAC(String ksfile, char[] pw, String alias) {
		KeyStore ks;
		String kstype = "";
		logger.info("Logging in to " + ksfile);
		if (ksfile.endsWith(".p12") || ksfile.endsWith(".pfx")) {
			logger.info("Loading P12 file: " + ksfile);
			kstype = "pkcs12";
		} else if (ksfile.endsWith(".p11")) {
			logger.warning("pkcs#11 not implemented yet");
		} else if (ksfile.endsWith(".jks")) {
			kstype = "jks";
		} else if (ksfile.equalsIgnoreCase("Windows-MY")) {
			kstype = ksfile;
			pw = null;
		} else {
			logger.info("Defaulting to JCEKS file: " + ksfile);
			kstype = "jceks";
		}
		try {
			ks = KeyStore.getInstance(kstype);

			FileInputStream fis = null;
			if (pw != null) {
			  fis = new FileInputStream(ksfile);
			}
			ks.load(fis, pw);
			logger.info("loaded " + ksfile + ", type = " + kstype);
			if (fis != null) fis.close();

			KeyAndCert kac = null;

			for (Enumeration e = ks.aliases(); e.hasMoreElements();) {
				String ksalias = (String) e.nextElement();
				
				logger.finer("found ksalias " + ksalias);

				Certificate[] cc = ks.getCertificateChain(ksalias);
				if (cc == null) {
					// Can be thrown when looked at a CA cert
					logger.fine("null chain from " + alias);
					continue;
				}

				X509Certificate[] xcc = new X509Certificate[cc.length];
				for (int i = 0; i < cc.length; i++) {
					X509Certificate xc = new X509Certificate(cc[i].getEncoded());
					xcc[i] = xc;
				}
				PrivateKey pk = (PrivateKey) ks.getKey(ksalias, pw);

				kac = new KeyAndCert(xcc, pk);
				return kac;

			}
		} catch (Exception e1) {
			logger.log(Level.WARNING, "load failed:", e1);
			e1.printStackTrace();
		}
		return null;
	}
}
