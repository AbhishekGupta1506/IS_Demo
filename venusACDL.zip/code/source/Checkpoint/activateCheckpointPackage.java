package Checkpoint;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2012-09-14 15:05:57 EDT
// -----( ON-HOST: MCDGAYHART02.AME.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.*;
// --- <<IS-END-IMPORTS>> ---

public final class activateCheckpointPackage

{
	// ---( internal utility methods )---

	final static activateCheckpointPackage _instance = new activateCheckpointPackage();

	static activateCheckpointPackage _newInstance() { return new activateCheckpointPackage(); }

	static activateCheckpointPackage _cast(Object o) { return (activateCheckpointPackage)o; }

	// ---( server methods )---




	public static final void copyCRMoAccessPackageToReplicateInbound (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(copyCRMoAccessPackageToReplicateInbound)>> ---
		// @sigtype java 3.5
		File fromFile = new File("packages/venusACDL/pub/CRMoDAccess.zip");
		File toFile = new File("replicate/inbound/CRMoDAccess.zip");
		FileInputStream from = null;
		FileOutputStream to = null;
		    try {
		      from = new FileInputStream(fromFile);
		      to = new FileOutputStream(toFile);
		      byte[] buffer = new byte[4096];
		      int bytesRead;
		      while ((bytesRead = from.read(buffer)) != -1)
		        to.write(buffer, 0, bytesRead); // write
		    }catch (IOException e) { throw new ServiceException(e); }
		    finally {
		      if (from != null)
		        try {
		          from.close();
		        } catch (IOException e) { System.err.println("Caught IOException: " + e.getMessage()); }
		      if (to != null)
		        try {
		          to.close();
		        } catch (IOException e) { System.err.println("Caught IOException: " + e.getMessage()); }
		    }
		// --- <<IS-END>> ---

                
	}
}

