

// -----( IS Java Code Template v1.2
// -----( CREATED: 2011-08-04 13:25:59 EDT
// -----( ON-HOST: tahiti.AME.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.app.b2b.server.cluster.ClusterManager;
// --- <<IS-END-IMPORTS>> ---

public final class Cluster

{
	// ---( internal utility methods )---

	final static Cluster _instance = new Cluster();

	static Cluster _newInstance() { return new Cluster(); }

	static Cluster _cast(Object o) { return (Cluster)o; }

	// ---( server methods )---




	public static final void isClusterEnabled (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(isClusterEnabled)>> ---
		// @sigtype java 3.5
		// [o] field:0:required isClusterEnabled
		// [o] field:0:required isCurrentlyInCluster
		String isClusterEnabled = ClusterManager.getClusterEnabled();
		String isCurrentlyInCluster = String.valueOf(ClusterManager.isCurrentlyClustered());
		
		IDataCursor idc = pipeline.getCursor();
		idc.last();
		idc.insertAfter("isClusterEnabled", isClusterEnabled);
		idc.insertAfter("isCurrentlyInCluster", isCurrentlyInCluster);
		
		idc.destroy();			
		// --- <<IS-END>> ---

                
	}
}

