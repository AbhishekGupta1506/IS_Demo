package deployMobileGateway;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2012-08-25 08:16:47 IST
// -----( ON-HOST: MCINVDU01.eur.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.lang.ns.NSName;
import com.wm.util.io.Streams;
import java.io.*;
import com.wm.app.b2b.server.*;
// --- <<IS-END-IMPORTS>> ---

public final class util

{
	// ---( internal utility methods )---

	final static util _instance = new util();

	static util _newInstance() { return new util(); }

	static util _cast(Object o) { return (util)o; }

	// ---( server methods )---




	public static final void compareLocalFileSize (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(compareLocalFileSize)>> ---
		// @sigtype java 3.5
		// [i] field:0:required file1
		// [i] field:0:required file2
		// [o] field:0:required result
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	file1 = IDataUtil.getString( pipelineCursor, "file1" );
		String	file2 = IDataUtil.getString( pipelineCursor, "file2" );
		pipelineCursor.destroy();
		
		File f1 = new File(file1);
		File f2 = new File(file2);
		 //
		
		
		if(!f1.exists()) {
		//	IDataUtil.put( pipelineCursor, "result", "FAILED : File : " + f1.getAbsolutePath() + " does not exist!" );
			IDataUtil.put( pipelineCursor, "result", "FAILED : File : " + file1 + " does not exist!" );
		
		}
		else if(!f2.exists()) {
		//	IDataUtil.put( pipelineCursor, "result", "FAILED : File : " + f2.getAbsolutePath() + " does not exist!" );
			IDataUtil.put( pipelineCursor, "result", "FAILED : File : " + file2 + " does not exist!" );
		
		}
		else {
			System.out.println("--------------------------------" + f1.length());
			System.out.println("--------------------------------" + f2.length());
			if (f1.length() == f2.length()) {
				IDataUtil.put( pipelineCursor, "result", "PASSED : Message = File 1 : " + file1+ " and File 2: " + file2 + " ::: File sizes matched.");
			}
			else {
				IDataUtil.put( pipelineCursor, "result", "FAILED : Message = File 1 : " + file1 + " of size = " + f1.length() + " and File 2: " + file2 + " of size = " + f2.length() + " ::: File sizes did not match.");
			}
		}
		
		if ( f2.exists())
			f2.delete();
		
		// pipeline
		pipelineCursor.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void copyFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(copyFile)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required filename
		// [i] field:0:required targetfile
		// [o] field:0:required result
		IDataCursor idc = pipeline.getCursor();  
		String nsName = IDataUtil.getString(idc,"filename");
		String targetFile = IDataUtil.getString(idc,"targetfile");
		String result = "Copy " + nsName + " to " + targetFile + ", result: ";
		 
		System.out.println(result);
		
		OutputStream out = null;
		InputStream in = null;
		try{ 
		      File f1 = new File(nsName);
		      File f2 = new File(targetFile);
		      in = new FileInputStream(f1);
		      
		      //For Append the file.
		//      OutputStream out = new FileOutputStream(f2,true);
		
		      //For Overwrite the file.
		      out = new FileOutputStream(f2);
		
		      byte[] buf = new byte[1024];
		      int len;
		      while ((len = in.read(buf)) > 0){
		        out.write(buf, 0, len);
		      }
		
		      result += "File copied.";
		    }
		    catch(FileNotFoundException ex){
		      result = ex.getMessage() + " in the specified directory.";
		    }
		    catch(IOException e){
		      result = e.getMessage();      
		    }
			finally{
				try{
					if(in != null){
						in.close();
					}
					if(out != null){
						out.close();
					}
				} catch(IOException ioe){
					// Ignore
				}
			}
		System.out.println(result);
		
		idc.last();
		IDataUtil.put(idc,"result",result);
		idc.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void deleteCopyFiles (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(deleteCopyFiles)>> ---
		// @sigtype java 3.5
		String bf = "packages" + File.separator + "venusACDL" + File.separator + "resources" + File.separator + "BigFile_copy.pdf";
		String sf = "packages" + File.separator + "venusACDL" + File.separator + "resources" + File.separator + "SmallFile_copy.pdf";
		
		File f = new File(bf);
		if ( f.exists())
			f.delete();
		
		f = new File(sf);
		if ( f.exists())
			f.delete();
				
		// --- <<IS-END>> ---

                
	}



	public static final void findString (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(findString)>> ---
		// @sigtype java 3.5
		// [i] field:0:required string1
		// [i] field:0:required string2
		// [o] field:0:required result
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	s = IDataUtil.getString( pipelineCursor, "string1" );
			String	s1 = IDataUtil.getString( pipelineCursor, "string2" );
		pipelineCursor.destroy();
		
		String s2 = "false";		
		boolean flag = s.contains(s1);
		if(flag)
		{
			s2 = "true";
		} else
		{
			s2 = "false";
		}
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "result", s2 );
		pipelineCursor_1.destroy();
			
			
		// --- <<IS-END>> ---

                
	}



	public static final void getFileAsBase64String (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getFileAsBase64String)>> ---
		// @sigtype java 3.5
		// [i] field:0:required inputFile
		// [o] field:0:required input
		// pipeline
		IDataCursor cur = pipeline.getCursor();
		String	inputFile = IDataUtil.getString( cur, "inputFile" );
		
		Resources resources = Server.getResources();
		
		File packageResDir = resources.getPackageResourceDir("venusACDL");
		File myFile = null;
		FileInputStream fis = null;
		
		
		try {
			   String pkgResourcePath = packageResDir.getCanonicalPath();
			   myFile = new File(pkgResourcePath, "SmallFile3.pdf");
			   if(!myFile.exists()) {
			        cur.insertAfter("input", null);
				return;
			   }
			
			   fis = new FileInputStream(myFile);
			   byte[] bytes = new byte[(int)myFile.length()];
			   fis.read(bytes);
			
			   cur.insertAfter("bytes", bytes);
			   Service.doInvoke("pub.string", "base64Encode", pipeline);
			
			   String encodedData = IDataUtil.getString(cur, "value");
			   IDataUtil.put(cur, "input", encodedData);
			   IDataUtil.remove(cur, "value");
			   IDataUtil.remove(cur, "bytes");
			}catch(Exception e) {
			   cur.insertAfter("input", null);
			   e.printStackTrace();
			}finally {
				   try {
					      if(fis != null) {
					         fis.close();
					      }
					   }catch(Exception e) {
					      //none
					   }
					   cur.destroy();
					}		
		
		// pipeline
		//		IDataCursor pipelineCursor = pipeline.getCursor();
		//		IDataUtil.put( pipelineCursor, "input", input );
		//		pipelineCursor.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void saveFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(saveFile)>> ---
		// @sigtype java 3.5
		// [i] field:0:required filename
		// [i] object:0:required fileStream
		// [o] field:0:required filename
		// pipeline
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	filename = IDataUtil.getString( pipelineCursor, "filename" );
		filename  = filename.substring(0, filename.indexOf('.')) + "_copy.pdf"; 
		InputStream	fis = (InputStream)IDataUtil.get( pipelineCursor, "fileStream" );
		OutputStream fos = null;
		try {
			fos = new FileOutputStream(new File(filename));
			Streams.pipe(fis, fos);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if (fos != null) {
				try {
					fos.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
		IDataUtil.put( pipelineCursor, "filename" , filename);
		pipelineCursor.destroy();
		
		// pipeline
		
		// pipeline
			
			
		// --- <<IS-END>> ---

                
	}



	public static final void sleep (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(sleep)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		//String timeInterval = ValuesEmulator.getString(pipeline, "interval");
		int numSec = 1;
		
		try{
			Thread.sleep(( numSec*1)* 1000L); 
		}catch(InterruptedException ie){
			// NO need to handle...
		}
			
		// --- <<IS-END>> ---

                
	}
}

