

// -----( IS Java Code Template v1.2
// -----( CREATED: 2012-09-14 15:01:18 EDT
// -----( ON-HOST: MCDGAYHART02.AME.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.*;
import java.io.*;
import com.wm.app.b2b.server.deployer.config.CompositeConfig;
import com.wm.app.b2b.server.deployer.config.ComponentConfig;
// --- <<IS-END-IMPORTS>> ---

public final class Utilities

{
	// ---( internal utility methods )---

	final static Utilities _instance = new Utilities();

	static Utilities _newInstance() { return new Utilities(); }

	static Utilities _cast(Object o) { return (Utilities)o; }

	// ---( server methods )---




	public static final void isACDLFileEqual (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(isACDLFileEqual)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required expectedFile
		// [i] field:0:required actualString
		// [o] field:0:required result
		// [o] field:0:required message
		IDataCursor cursor = pipeline.getCursor();
		String expected = IDataUtil.getString(cursor, "expectedFile");
		String actualString = IDataUtil.getString(cursor, "actualString");
		String actual = expected + ".actual.acdl";
		
		try {
		    BufferedWriter out = new BufferedWriter(new FileWriter(actual));
		    out.write(actualString);
		    out.close();
		} catch (IOException e) {
		}
		
		File exp = new File(expected);
		File act = new File(actual);
		boolean eq = false;
		String message = "";
		 
		try {
			eq = isACDLDocumentEqual(exp, act);
		} catch (Exception e) {
			message = e.getMessage();	
		}
		
		if (!eq) {
			message = "Files differ: diff " + expected + " " + actual;
		}
		
		IDataUtil.put(cursor, "result", eq);
		IDataUtil.put(cursor, "message", message);
		cursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void isACDLStringEqual (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(isACDLStringEqual)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required expectedString
		// [i] field:0:required actualString
		// [o] field:0:required result
		// [o] field:0:required message
		IDataCursor cursor = pipeline.getCursor();
		String expectedString = IDataUtil.getString(cursor, "expectedString");
		String actualString = IDataUtil.getString(cursor, "actualString");
		boolean eq = false;
		String message = "";
		
		try {
			/*
		    File expected = File.createTempFile("expected", ".acdl");
		    File actual = File.createTempFile("actual", ".acdl");
		
		
		    BufferedWriter out1 = new BufferedWriter(new FileWriter(expected));
		    out1.write(expectedString);
		    out1.close();
		
		    BufferedWriter out2 = new BufferedWriter(new FileWriter(actual));
		    out2.write(actualString);
		    out2.close();
			*/
		
			InputStream expected = new ByteArrayInputStream(expectedString.getBytes());
			InputStream actual = new ByteArrayInputStream(actualString.getBytes());
			try {
			eq = isACDLDocumentEqual(expected, actual);
		    } catch (Exception e) {
			message = e.getMessage();
			e.printStackTrace();
		    }
		
		} catch (Exception e) {
			message = e.getMessage();
			e.printStackTrace();
		}
		
		if (!eq && (message == "")) {
			message = "FAILED: Strings differ:  Expected:\n\n" + expectedString + "\n\nActual:\n\n" + actualString;
		}
		
		IDataUtil.put(cursor, "result", eq);
		IDataUtil.put(cursor, "message", message);
		cursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void removeXMLElementFromString (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(removeXMLElementFromString)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required xmlString
		// [i] field:0:required xmlElement
		// [o] field:0:required isRemoved
		// [o] field:0:required revisedString
		IDataCursor cursor = pipeline.getCursor();
		try
		{
			String xml = IDataUtil.getString(cursor, "xmlString");
			if(xml == null || xml.length() == 0) {
				throw new IllegalArgumentException("xmlString is a required parameter. Supply a value for xmlString");
			}
			String xmlElement = IDataUtil.getString(cursor, "xmlElement");
			// xmlElement example is "  <buildInfo name="BuildTimestamp" value="
			if(xmlElement == null || xmlElement.length() == 0) {
				throw new IllegalArgumentException("xmlElement is a required parameter. Supply a value for xmlElement");
			}
			int begin = xml.indexOf(xmlElement);
			StringBuilder revised = new StringBuilder();
			boolean isRemoved = false;
			if(begin >=0) {
				int end = xml.indexOf("/>", begin);
				if(end > 0) {
					revised.append(xml.substring(0, begin-1));
					System.out.println(xml.substring(0, begin-1));
					revised.append(xml.substring(end+2));
					System.out.println(xml.substring(end+4));
		 // why 4? 2 chars to skip "/>" and 2 to skip "\r\n"
					isRemoved = true; 
				} else {
					isRemoved = false;
				}
			} else {
				isRemoved = false;
			}
			if(!isRemoved) {
				revised.append(xml);
			}
			IDataUtil.put(cursor, "revisedString", revised.toString());
			IDataUtil.put(cursor, "isRemoved", String.valueOf(isRemoved));
		} catch(Throwable t) {
			throw new ServiceException(t);
		} finally {
			cursor.destroy();
		}
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
		public static boolean isACDLDocumentEqual(File srcDocFile, File targetDocFile) throws Exception {
			CompositeConfig srcComposite = new CompositeConfig(srcDocFile);
			CompositeConfig targetComposite = new CompositeConfig(targetDocFile);
	
			return srcComposite.equals(targetComposite);
		}
	
		public static boolean isACDLDocumentEqual(InputStream srcDocStream, InputStream targetDocStream) throws Exception {
			CompositeConfig srcComposite = new CompositeConfig(srcDocStream);
			CompositeConfig targetComposite = new CompositeConfig(targetDocStream);
	
			return srcComposite.equals(targetComposite);
		}
	
		
		public static CompositeConfig createCompositeConfig(File acdlFile) {
			
			CompositeConfig compositeCfg = null;
			try {
				FileInputStream acdlStream = new FileInputStream(acdlFile);
		  		compositeCfg = new CompositeConfig(acdlStream);
			} catch (Exception e) {
				e.printStackTrace();
			} 
			return compositeCfg;
		}
		
	    // Verifies the presence of all instances of an assetType within an ACDL file.
		public static void checkACDLFile(File acdlFile, String[] expectedAssets, String assetType) {
			System.out.println("  ** checkACDLFile "+acdlFile.getPath());	
			System.out.println("  ** checkACDLFile asset type = "+assetType);
			if (acdlFile.exists()) {
			
			CompositeConfig compositeCfg = createCompositeConfig(acdlFile);
			
			List<ComponentConfig> components = compositeCfg.getComponents(assetType);
		if (expectedAssets.length != components.size()) {
			System.out.println("Wrong number of assets found for " + assetType);
		}
			
			for (String asset : expectedAssets) {
	System.out.println("  ** checkACDLFile asset name = "+asset);
		if (compositeCfg.getComponent(asset, assetType) == null)
			System.out.println(asset+" ("+assetType+") not found");
			}
	}
		}	
		
	// --- <<IS-END-SHARED>> ---
}

