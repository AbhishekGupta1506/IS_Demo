

// -----( IS Java Code Template v1.2
// -----( CREATED: 2012-02-12 18:24:52 EST
// -----( ON-HOST: MCDGAYHART01.AME.ad.sag

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.softwareag.util.IDataMap;
// --- <<IS-END-IMPORTS>> ---

public final class util

{
	// ---( internal utility methods )---

	final static util _instance = new util();

	static util _newInstance() { return new util(); }

	static util _cast(Object o) { return (util)o; }

	// ---( server methods )---




	public static final void getSize (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getSize)>> ---
		// @sigtype java 3.5
		// [i] record:1:required docListInput
   IDataMap pipe = new IDataMap(pipeline);
   IData[] docListInput = pipe.getAsIDataArray("docListInput");
   int docListSize; 
   
   docListSize = docListInput.length;
   pipe.put("docListSize", docListSize);
   String[] newStringList = new String[docListSize - 1];
   pipe.put("newStringList", newStringList);
		// --- <<IS-END>> ---

                
	}



	public static final void populateTypeArray (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(populateTypeArray)>> ---
		// @sigtype java 3.5
		// [i] field:1:required strList
		// [i] field:0:required iteration
		// [i] field:0:required inStr
 IDataMap pipe = new IDataMap(pipeline);
 
 String[] stringList = pipe.getAsStringArray("strList");
 Integer index = pipe.getAsInteger("iteration");
 String stringInput = pipe.getAsString("inStr");
 
 
 stringList[index - 2] = stringInput;
 
 pipe.put("stringList", stringList);
		// --- <<IS-END>> ---

                
	}
}

